<?php
$filepath = realpath(dirname(__FILE__));
include_once($filepath . '/../config/config.php');

class Database {

    public $host   = DB_HOST;
    public $user   = DB_USER;
    public $pass   = DB_PASS;
    public $dbname = DB_NAME;

    public $link;
    public $error;

    public function __construct() {
        $this->connectDB();
    }

    private function connectDB() {
        $this->link = new mysqli($this->host, $this->user, $this->pass, $this->dbname);

        if ($this->link->connect_error) {
            $this->error = "Connection failed: " . $this->link->connect_error;
            echo "<h3 style='color:red'>Database Connection Error: {$this->error}</h3>";
            return false;
        }
    }

    // Select or Read data
    public function select($query) {
        $result = $this->link->query($query);

        if ($result === false) {
            echo "<h3 style='color:red'>SQL Error (SELECT): " . $this->link->error . "</h3>";
            echo "<pre style='color:#333;background:#f8f8f8;padding:10px;border:1px solid #ddd'>QUERY: $query</pre>";
            return false;
        }

        if ($result->num_rows > 0) {
            return $result;
        } else {
            return false;
        }
    }

    // Insert data
    public function insert($query) {
        $insert_row = $this->link->query($query);

        if ($insert_row === false) {
            echo "<h3 style='color:red'>SQL Error (INSERT): " . $this->link->error . "</h3>";
            echo "<pre style='color:#333;background:#f8f8f8;padding:10px;border:1px solid #ddd'>QUERY: $query</pre>";
            return false;
        }

        return $insert_row;
    }

    // Update data
    public function update($query) {
        $update_row = $this->link->query($query);

        if ($update_row === false) {
            echo "<h3 style='color:red'>SQL Error (UPDATE): " . $this->link->error . "</h3>";
            echo "<pre style='color:#333;background:#f8f8f8;padding:10px;border:1px solid #ddd'>QUERY: $query</pre>";
            return false;
        }

        return $update_row;
    }

    // Delete data
    public function delete($query) {
        $delete_row = $this->link->query($query);

        if ($delete_row === false) {
            echo "<h3 style='color:red'>SQL Error (DELETE): " . $this->link->error . "</h3>";
            echo "<pre style='color:#333;background:#f8f8f8;padding:10px;border:1px solid #ddd'>QUERY: $query</pre>";
            return false;
        }

        return $delete_row;
    }
}
?>
