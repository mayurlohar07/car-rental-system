<?php include 'inc/header.php'; ?>
<?php
Session::checkLogin();
?>

<style>
body{
    background:#f4f6f9;
}
.login-box{
    background:#ffffff;
    padding:40px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    margin-top:50px;
    margin-bottom:50px;
}
.page-title{
    background:linear-gradient(135deg,#007bff,#6610f2);
    color:#fff;
    padding:30px;
    border-radius:12px;
    text-align:center;
    margin-bottom:30px;
}
.page-title h1{
    margin:0;
    font-size:34px;
    font-weight:700;
}
.page-title p{
    margin-top:10px;
    font-size:16px;
    opacity:.9;
}
.logo-img{
    margin-top:15px;
}
.btn-login{
    width:100%;
    padding:12px;
    font-size:18px;
    border-radius:10px;
}
.signup-btn{
    width:100%;
    border-radius:10px;
}
.msg-text{
    display:block;
    margin-top:10px;
    font-weight:600;
}
</style>

<div class="container">

    <div class="row justify-content-center">

        <div class="col-lg-6">

            <div class="login-box">

                <div class="page-title">
                    <h1>Online Examination System</h1>
                    <p>Simple MCQ Based Online Examination System!</p>
                    <img src="img/bgtest.png" width="120" class="logo-img"/>
                </div>

                <form action="index.php" method="post">

                    <div class="form-group">
                        <label><strong>Email Address</strong></label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email">
                    </div>

                    <div class="form-group">
                        <label><strong>Password</strong></label>
                        <input type="password" name="password" id="password" class="form-control" placeholder="Password">
                    </div>

                    <button type="submit" id="loginsubm" value="Signup" class="btn btn-success btn-login">
                        Log In
                    </button>

                </form>

                <br/>

                <p>
                    <a class="btn btn-outline-info btn-lg signup-btn" href="register.php">
                        New User? Signup for Free
                    </a>
                </p>

                <span class="empty text-danger msg-text" style="display:none;">
                    Fields must not be empty
                </span>

                <span class="disable text-warning msg-text" style="display:none;">
                    User ID Disable!
                </span>

                <span class="error text-danger msg-text" style="display:none;">
                    Email or Password did not match.
                </span>

            </div>

        </div>

    </div>

</div>

<?php include 'inc/footer.php'; ?>