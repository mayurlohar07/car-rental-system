</body>

<!-- Footer -->
<section id="footer">
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
            <ul class="list-unstyled list-inline social text-center">
                <li class="list-inline-item"><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li class="list-inline-item"><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li class="list-inline-item"><a href="#"><i class="fa fa-instagram"></i></a></li>
                <li class="list-inline-item"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li class="list-inline-item"><a href="#"><i class="fa fa-envelope"></i></a></li>
            </ul>
        </div>
    </div>    

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 mt-2 text-center text-white">
            <p class="h6">&copy; Creative Commons 4.0. Developed by Vishal Pardhi</p>
        </div>
    </div>
</section>
<!-- ./Footer -->

<!-- Correct JavaScript Includes -->
<script src="js/jquery.js"></script>
<!-- Bootstrap bundle temporarily disabled (missing local file, was 404) -->
<!-- <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script> -->

</html>
