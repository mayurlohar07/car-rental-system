<?php

$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/../lib/Session.php');
Session::init();

include_once ($filepath.'/../lib/Database.php');
include_once ($filepath.'/../helpers/Format.php');

spl_autoload_register(function($class){
    include_once "classes/".$class.".php";
});

$db   = new Database();
$fm   = new Format();
$exam = new Exam();
$user = new User();
$pro  = new Process();

/* Prevent caching */
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: pre-check=0, post-check=0, max-age=0");
header("Pragma: no-cache");
header("Expires: Mon, 6 Dec 1977 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");

/* Logout */
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    Session::destroy();
    header("Location:index.php");
    exit();
}
?>

<!doctype html>
<html>
<head>
    <title>Online Exam System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/main.css">

    <script src="js/jquery.js"></script>
    <script src="js/main.js"></script>

<style>
body{
    background:#f4f6f9;
}

/* Navbar */
.navbar{
    background:#ffffff !important;
    padding:14px 0;
    box-shadow:0 6px 18px rgba(0,0,0,0.08);
    border-bottom:1px solid #ececec;
}

.navbar-brand{
    color:#111 !important;
    font-size:24px;
    font-weight:700;
}

/* Menu */
.navbar-nav{
    align-items:center;
}

.navbar-nav .nav-item{
    margin-left:8px;
}

.navbar-nav .nav-link{
    color:#333 !important;
    font-weight:600;
    padding:12px 18px !important;
    border-radius:8px;
    min-width:115px;
    height:44px;
    display:flex;
    align-items:center;
    justify-content:center;
    white-space:nowrap;
    transition:all .3s ease;
}

.navbar-nav .nav-link:hover{
    transform:translateY(-2px);
    box-shadow:0 8px 18px rgba(0,0,0,0.08);
}

/* Colors */
.welcome-btn{
    background:#eef2ff;
    color:#4338ca !important;
    min-width:220px;
}

.profile-btn{
    background:#e8fff3;
    color:#198754 !important;
}

.exam-btn{
    background:#fff8e5;
    color:#d39e00 !important;
}

.login-btn{
    background:#e8f0ff;
    color:#0d6efd !important;
}

.register-btn{
    background:#f3e8ff;
    color:#6f42c1 !important;
}

.admin-btn{
    background:#e7fbff;
    color:#0dcaf0 !important;
}

.logout-btn{
    background:#dc3545;
    color:#fff !important;
}

.logout-btn:hover{
    background:#bb2d3b !important;
    color:#fff !important;
}

.navbar-toggler{
    border:none;
}

.navbar-toggler:focus{
    outline:none;
    box-shadow:none;
}
</style>

</head>

<body>

<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-light static-top">
<div class="container">

    <a class="navbar-brand" href="index.php">
        Online Examination System
    </a>

    <button class="navbar-toggler" type="button" data-toggle="collapse"
            data-target="#navbarResponsive">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">

        <?php
        $login = Session::get("login");
        if ($login == true) {
        ?>

            <li class="nav-item">
                <a class="nav-link welcome-btn" href="#">
                    Welcome <?php echo Session::get("name"); ?>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link profile-btn" href="profile.php">
                    Profile
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link exam-btn" href="exam.php">
                    Exam
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link logout-btn" href="?action=logout">
                    Logout
                </a>
            </li>

        <?php } else { ?>

            <li class="nav-item">
                <a class="nav-link login-btn" href="index.php">
                    Login
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link register-btn" href="register.php">
                    Register
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link admin-btn" href="admin/">
                    Admin
                </a>
            </li>

        <?php } ?>

        </ul>
    </div>

</div>
</nav>