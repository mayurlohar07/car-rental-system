<?php
$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/inc/loginheader.php');
include_once ($filepath.'/../classes/Admin.php');
$ad = new Admin();
?>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $adminData = $ad->getAdminData($_POST);
}
?>

<div class="container py-5">

    <div class="row justify-content-center">

        <div class="col-lg-6">

            <div class="card border-0 shadow-lg rounded-4 overflow-hidden">

                <!-- Header -->
                <div class="text-center text-white p-5"
                     style="background:linear-gradient(135deg,#dc3545,#6610f2);">

                    <h1 class="fw-bold mb-2">Administration Panel</h1>

                    <p class="lead mb-0">Secure Admin Login Portal</p>

                </div>

                <!-- Form Body -->
                <div class="p-5 bg-white">

                    <form action="" method="post">

                        <div class="form-group mb-4">
                            <label class="fw-bold mb-2">Username</label>
                            <input type="text"
                                   class="form-control form-control-lg rounded-3"
                                   name="adminUser"
                                   placeholder="Enter Username">
                        </div>

                        <div class="form-group mb-4">
                            <label class="fw-bold mb-2">Password</label>
                            <input type="password"
                                   class="form-control form-control-lg rounded-3"
                                   name="adminPass"
                                   placeholder="Enter Password">
                        </div>

                        <div class="d-grid">
                            <button type="submit"
                                    name="login"
                                    value="Login"
                                    class="btn btn-danger btn-lg rounded-3 shadow-sm w-100">

                                Log In
                            </button>
                        </div>

                    </form>

                    <br>

                    <?php
                    if (isset($adminData)) {
                        echo $adminData;
                    }
                    ?>

                </div>

            </div>

        </div>

    </div>

</div>

<?php include '../inc/footer.php'; ?>