<?php include 'inc/header.php'; ?>

<?php
$query = "
    SELECT 
        r.*, 
        e.exam_name
    FROM tbl_results r
    JOIN tbl_exam e ON e.exam_id = r.exam_id
    ORDER BY r.attempt_date DESC
";

$result = $db->select($query);
?>

<style>
body{
    background:#f4f6f9;
}
.result-box{
    background:#ffffff;
    padding:35px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    margin-top:40px;
    margin-bottom:40px;
}
.page-title{
    background:linear-gradient(135deg,#007bff,#6610f2);
    color:#fff;
    padding:25px;
    border-radius:12px;
    text-align:center;
    margin-bottom:30px;
}
.page-title h1{
    margin:0;
    font-size:32px;
    font-weight:700;
}
.table thead{
    background:#343a40;
    color:#fff;
}
.table td,
.table th{
    text-align:center;
    vertical-align:middle;
}
.correct{
    color:green;
    font-weight:bold;
}
.wrong{
    color:red;
    font-weight:bold;
}
.percent{
    font-weight:bold;
    color:#007bff;
}
</style>

<div class="container">

    <div class="result-box">

        <div class="page-title">
            <h1>All Exam Results</h1>
        </div>

        <div class="table-responsive">

            <table class="table table-bordered table-hover table-striped">

                <thead>
                    <tr>
                        <th>#</th>
                        <th>User ID</th>
                        <th>User Name</th>
                        <th>Exam Name</th>
                        <th>Total Questions</th>
                        <th>Correct</th>
                        <th>Wrong</th>
                        <th>Percentage</th>
                        <th>Attempt Date</th>
                    </tr>
                </thead>

                <tbody>

                <?php 
                if ($result) {
                    $i = 1;

                    while ($row = $result->fetch_assoc()) {
                ?>

                    <tr>

                        <td><?php echo $i++; ?></td>

                        <td><?php echo $row['user_id']; ?></td>

                        <td>
                            <strong><?php echo $row['username']; ?></strong>
                        </td>

                        <td><?php echo $row['exam_name']; ?></td>

                        <td><?php echo $row['total_questions']; ?></td>

                        <td class="correct">
                            <?php echo $row['correct_questions']; ?>
                        </td>

                        <td class="wrong">
                            <?php echo $row['wrong_questions']; ?>
                        </td>

                        <td class="percent">
                            <?php echo number_format($row['percentage'],2); ?>%
                        </td>

                        <td><?php echo $row['attempt_date']; ?></td>

                    </tr>

                <?php } } else { ?>

                    <tr>
                        <td colspan="9" class="text-danger text-center">
                            No Results Found
                        </td>
                    </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php include 'inc/footer.php'; ?>