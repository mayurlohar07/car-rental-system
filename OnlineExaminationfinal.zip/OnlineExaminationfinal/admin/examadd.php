<?php
$filepath = realpath(dirname(__FILE__));
include_once($filepath . '/inc/header.php');
include_once($filepath . '/../classes/Exam.php');
$exam = new Exam();
?>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $addExam = $exam->getAddExam($_POST);
}
?>

<style>
    body {
        background: #f4f6f9;
    }

    .form-box {
        background: #ffffff;
        padding: 40px;
        border-radius: 15px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
        margin-top: 40px;
        margin-bottom: 40px;
    }

    .page-title {
        background: linear-gradient(135deg, #198754, #20c997);
        color: #fff;
        padding: 25px;
        border-radius: 12px;
        text-align: center;
        margin-bottom: 30px;
    }

    .page-title h1 {
        margin: 0;
        font-size: 32px;
        font-weight: 700;
    }

    .table td {
        padding: 12px;
        vertical-align: middle;
    }

    .form-control {
        border-radius: 10px;
        height: 48px;
    }

    textarea.form-control {
        height: auto;
    }

    .form-control:focus {
        border-color: #198754;
        box-shadow: 0 0 0 0.15rem rgba(25, 135, 84, .15);
    }

    .btn-submit {
        padding: 12px 40px;
        font-size: 18px;
        border-radius: 10px;
        background: #198754;
        border: none;
    }

    .btn-submit:hover {
        background: #157347;
    }

    small.text-muted {
        font-size: 13px;
    }
</style>

<div class="container">
    <div class="row justify-content-center">

        <div class="col-lg-8">

            <div class="form-box">

                <div class="page-title">
                    <h1>Add Exam</h1>
                </div>

                <?php
                if (isset($addExam)) {
                    echo $addExam;
                }
                ?>

                <form action="" method="post" name="tbl_exam">

                    <table class="table table-borderless">

                        <tr>
                            <td width="32%"><strong>Exam Name</strong></td>
                            <td width="5%">:</td>
                            <td>
                                <input class="form-control" type="text" name="examName" placeholder="Enter Exam Name" required>
                            </td>
                        </tr>

                        <tr>
                            <td><strong>Description</strong></td>
                            <td>:</td>
                            <td>
                                <textarea class="form-control" name="examDesc" rows="4" placeholder="Enter Exam Description" required></textarea>
                            </td>
                        </tr>

                        <tr>
                            <td><strong>Exam Date</strong></td>
                            <td>:</td>
                            <td>
                                <input class="form-control" type="date" name="examDate" required>
                            </td>
                        </tr>

                        <tr>
                            <td><strong>Duration (Minutes)</strong></td>
                            <td>:</td>
                            <td>
                                <input class="form-control" type="number" name="examDuration" placeholder="Enter Duration" required>
                            </td>
                        </tr>

                        <tr>
                            <td><strong>Total Questions</strong></td>
                            <td>:</td>
                            <td>
                                <input class="form-control" type="number" name="totalQuestions" placeholder="Enter Total Questions" required>
                            </td>
                        </tr>

                        <!-- PAYMENT FIELD -->
                        <tr>
                            <td><strong>Exam Fee (₹)</strong></td>
                            <td>:</td>
                            <td>
                                <input
                                    class="form-control"
                                    type="number"
                                    name="exam_fee"
                                    placeholder="Enter Exam Fee (0 for Free Exam)"
                                    min="0"
                                    max="1000"
                                    step="0.01"
                                    required>

                                <small class="text-muted">
                                    Enter 0 for free exam. You can also set values like 10, 10.50, 25 etc.
                                </small>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="3" class="text-center pt-4">
                                <input type="submit" class="btn btn-submit" value="Add Exam">
                            </td>
                        </tr>

                    </table>

                </form>

            </div>

        </div>

    </div>
</div>

<?php include '../inc/footer.php'; ?>