<?php 
$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/inc/header.php');
include_once ($filepath.'/../classes/Exam.php');
$exam = new Exam();
?>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $addQuestion = $exam->addQuestionToExam($_POST);
}

$getExam = $exam->getAllExams();
?>

<style>
body{
    background:#f4f6f9;
}
.form-box{
    background:#ffffff;
    padding:40px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    margin-top:40px;
    margin-bottom:40px;
}
.page-title{
    background:linear-gradient(135deg,#007bff,#6610f2);
    color:#fff;
    padding:25px;
    border-radius:12px;
    text-align:center;
    margin-bottom:30px;
}
.page-title h1{
    margin:0;
    font-size:32px;
    font-weight:700;
}
.table td{
    padding:12px;
    vertical-align:middle;
}
.btn-submit{
    padding:12px 35px;
    font-size:18px;
    border-radius:10px;
}
</style>

<div class="container">
    <div class="row justify-content-center">

        <div class="col-lg-8">

            <div class="form-box">

                <div class="page-title">
                    <h1>Add Questions</h1>
                </div>

                <?php 
                if (isset($addQuestion)) { 
                    echo $addQuestion; 
                } 
                ?>

                <form action="" method="post" name="tbl_ans">

                    <table class="table table-borderless">

                        <tr>
                            <td width="30%"><strong>Select Exam</strong></td>
                            <td width="5%">:</td>
                            <td>
                                <select class="form-control" name="exam_id" required>
                                    <option value="">Select Exam</option>

                                    <?php
                                    if ($getExam) {
                                        while ($result = $getExam->fetch_assoc()) {
                                    ?>
                                    <option value="<?php echo $result['exam_id']; ?>">
                                        <?php echo $result['exam_name']; ?>
                                    </option>
                                    <?php } } ?>

                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td><strong>Question</strong></td>
                            <td>:</td>
                            <td>
                                <input class="form-control" type="text" name="question" placeholder="Enter Question" required>
                            </td>
                        </tr>

                        <tr>
                            <td><strong>Choice 1</strong></td>
                            <td>:</td>
                            <td>
                                <input class="form-control" type="text" name="option1" required>
                            </td>
                        </tr>

                        <tr>
                            <td><strong>Choice 2</strong></td>
                            <td>:</td>
                            <td>
                                <input class="form-control" type="text" name="option2" required>
                            </td>
                        </tr>

                        <tr>
                            <td><strong>Choice 3</strong></td>
                            <td>:</td>
                            <td>
                                <input class="form-control" type="text" name="option3" required>
                            </td>
                        </tr>

                        <tr>
                            <td><strong>Choice 4</strong></td>
                            <td>:</td>
                            <td>
                                <input class="form-control" type="text" name="option4" required>
                            </td>
                        </tr>

                        <tr>
                            <td><strong>Correct Option No</strong></td>
                            <td>:</td>
                            <td>
                                <input class="form-control" type="number" name="answer" min="1" max="4" required>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="3" class="text-center pt-4">
                                <input type="submit" class="btn btn-success btn-submit" value="Submit Question">
                            </td>
                        </tr>

                    </table>

                </form>

            </div>

        </div>

    </div>
</div>

<?php include '../inc/footer.php'; ?>