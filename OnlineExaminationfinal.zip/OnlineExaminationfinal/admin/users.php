<?php 
$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/inc/header.php');
include_once ($filepath.'/../classes/User.php');

$user = new User();

if (isset($_GET['dis'])) {
    $user->disableUser((int)$_GET['dis']);
}

if (isset($_GET['ena'])) {
    $user->enaUser((int)$_GET['ena']);
}

if (isset($_GET['del'])) {
    $user->delUser((int)$_GET['del']);
}
?>

<div class="container">
    <div class="user-box">

        <div class="page-title">
            <h1>Manage Users</h1>
        </div>

        <div class="table-responsive">

            <table class="table table-bordered table-hover table-striped">

                <thead>
                    <tr>
                        <th>#</th>
                        <th>NAME</th>
                        <th>USERNAME</th>
                        <th>EMAIL</th>
                        <th>ACTION</th>
                    </tr>
                </thead>

                <tbody>

                <?php
                $userData = $user->getUserData();

                if ($userData) {
                    $i = 0;

                    while ($result = $userData->fetch_assoc()) {
                        $i++;
                ?>

                    <tr>

                        <td>
                            <?php echo ($result['status'] == 1) ? "<span class='badge-disabled'>$i</span>" : $i; ?>
                        </td>

                        <td><?php echo $result['name']; ?></td>
                        <td><?php echo $result['userName']; ?></td>
                        <td><?php echo $result['email']; ?></td>

                        <td>

                            <a class="btn btn-primary btn-sm"
                               href="edituser.php?id=<?php echo $result['userId']; ?>">
                               <i class="fa fa-edit"></i> Edit
                            </a>

                            <a class="btn btn-danger btn-sm"
                               onclick="return confirm('Are you sure to Delete?')"
                               href="?del=<?php echo $result['userId']; ?>">
                               <i class="fa fa-trash"></i> Delete
                            </a>

                        </td>

                    </tr>

                <?php } } ?>

                </tbody>

            </table>

        </div>

    </div>
</div>

<?php include '../inc/footer.php'; ?>