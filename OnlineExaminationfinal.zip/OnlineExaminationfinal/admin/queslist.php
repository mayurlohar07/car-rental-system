<?php 
$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/inc/header.php');
include_once ($filepath.'/../classes/Exam.php');
$exam = new Exam();
?>

<?php
if (isset($_GET['delque'])) {
    $que_id = (int)$_GET['delque'];

    $delresult = $exam->deleteQuestion($que_id);

    $redirect_url = "queslist.php";

    if (isset($_GET['exam_id'])) {
        $redirect_url .= "?exam_id=".(int)$_GET['exam_id'];
    }

    $redirect_url .= (strpos($redirect_url,'?') !== false ? '&' : '?') . "msg=" . ($delresult ? "success" : "error");

    header("Location: $redirect_url");
    exit();
}

$getExam = $exam->getAllExams();
$selected_exam = isset($_GET['exam_id']) ? (int)$_GET['exam_id'] : null;
?>

<style>
body{
    background:#f4f6f9;
}
.list-box{
    background:#ffffff;
    padding:35px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    margin-top:40px;
    margin-bottom:40px;
}
.page-title{
    background:linear-gradient(135deg,#007bff,#6610f2);
    color:#fff;
    padding:25px;
    border-radius:12px;
    text-align:center;
    margin-bottom:30px;
}
.page-title h1{
    margin:0;
    font-size:32px;
    font-weight:700;
}
.table thead{
    background:#343a40;
    color:#fff;
}
.table td,
.table th{
    text-align:center;
    vertical-align:middle;
}
.btn-remove{
    padding:7px 18px;
    border-radius:8px;
}
.filter-box{
    background:#f8f9fa;
    padding:20px;
    border-radius:12px;
    margin-bottom:25px;
}
</style>

<div class="container">

    <div class="list-box">

        <?php
        if (isset($_GET['msg'])) {
            if ($_GET['msg'] == 'success') {
                echo "<div class='alert alert-success'>Question Deleted Successfully!</div>";
            } elseif ($_GET['msg'] == 'error') {
                echo "<div class='alert alert-danger'>Question Not Deleted.</div>";
            }
        }
        ?>

        <div class="page-title">
            <h1>Question List</h1>
        </div>

        <div class="filter-box">

            <form method="GET" action="">

                <div class="form-group">
                    <label><strong>Select Exam</strong></label>

                    <select class="form-control" name="exam_id" onchange="this.form.submit()">
                        <option value="">All Exams</option>

                        <?php
                        if ($getExam) {
                            while ($examResult = $getExam->fetch_assoc()) {
                        ?>

                        <option value="<?php echo $examResult['exam_id']; ?>"
                            <?php if ($selected_exam == $examResult['exam_id']) echo 'selected'; ?>>

                            <?php echo $examResult['exam_name']; ?>

                        </option>

                        <?php } } ?>

                    </select>
                </div>

            </form>

        </div>

        <div class="table-responsive">

            <table class="table table-bordered table-hover table-striped">

                <thead>
                    <tr>
                        <th width="10%">#</th>
                        <th width="70%">Question</th>
                        <th width="20%">Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php
                $questionData = $exam->getQuestionsByExam($selected_exam);

                if ($questionData) {
                    $i = 0;

                    while ($result = $questionData->fetch_assoc()) {
                        $i++;
                ?>

                    <tr>
    <td><?php echo $i; ?></td>

    <td class="text-left">
        <?php echo $result['question']; ?>
    </td>

    <td>
        <div style="display:flex; justify-content:center; gap:10px;">

            <!-- EDIT -->
            <a class="btn btn-primary btn-sm"
               href="editQuestion.php?que_id=<?php echo $result['que_id']; ?><?php if ($selected_exam) echo '&exam_id='.$selected_exam; ?>">
               Edit
            </a>

            <!-- DELETE -->
            <a class="btn btn-danger btn-sm"
               onclick="return confirm('Delete this question?')"
               href="?delque=<?php echo $result['que_id']; ?><?php if ($selected_exam) echo '&exam_id='.$selected_exam; ?>">
               Remove
            </a>

        </div>
    </td>
</tr>

                <?php } } ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php include '../inc/footer.php'; ?>