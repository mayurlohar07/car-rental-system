<?php
$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/inc/header.php');
include_once ($filepath.'/../classes/Exam.php');

$exam = new Exam();

if (!isset($_GET['id'])) {
    header("Location: examlist.php");
    exit();
}

$id = (int)$_GET['id'];

/* fetch exam data */
$data = $exam->getExamById($id);
$row = $data ? $data->fetch_assoc() : null;

/* update */
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $update = $exam->updateExam($_POST, $id);
}
?>

<style>
body{
    background:linear-gradient(135deg,#eef2f7,#dfe9f3);
}

/* Main Card */
.edit-box{
    max-width:850px;
    margin:60px auto;
    background:#fff;
    border-radius:18px;
    padding:40px;
    box-shadow:0 15px 35px rgba(0,0,0,0.08);
}

/* Header */
.top-title{
    background:linear-gradient(135deg,#0d6efd,#6f42c1);
    color:#fff;
    padding:25px;
    border-radius:14px;
    text-align:center;
    margin-bottom:30px;
}

.top-title h2{
    margin:0;
    font-size:30px;
    font-weight:700;
}

.top-title p{
    margin:5px 0 0;
    opacity:.9;
}

/* Labels */
label{
    font-weight:600;
    margin-bottom:8px;
    color:#333;
}

/* Inputs */
.form-control{
    border-radius:10px;
    min-height:50px;
    border:1px solid #dcdcdc;
    padding-left:15px;
    font-size:15px;
}

textarea.form-control{
    min-height:120px;
    padding-top:12px;
    resize:none;
}

.form-control:focus{
    border-color:#0d6efd;
    box-shadow:0 0 0 0.15rem rgba(13,110,253,.15);
}

/* Buttons */
.btn-custom{
    min-width:160px;
    height:48px;
    border:none;
    border-radius:10px;
    font-weight:600;
    transition:.3s;
}

.btn-update{
    background:#198754;
    color:#fff;
}

.btn-update:hover{
    background:#157347;
}

.btn-back{
    background:#6c757d;
    color:#fff;
}

.btn-back:hover{
    background:#5c636a;
}

.btn-custom:hover{
    transform:translateY(-2px);
}
</style>

<div class="container">

    <div class="edit-box">

        <div class="top-title">
            <h2>Edit Exam</h2>
            <p>Update exam details professionally</p>
        </div>

        <?php
        if (isset($update)) {
            echo $update;
        }
        ?>

        <?php if ($row) { ?>

        <form method="post">

            <div class="row">

                <div class="col-md-6 mb-3">
                    <label>Exam Name</label>
                    <input type="text" name="examName" class="form-control"
                           value="<?php echo $row['exam_name']; ?>">
                </div>

                <div class="col-md-6 mb-3">
                    <label>Date</label>
                    <input type="date" name="examDate" class="form-control"
                           value="<?php echo $row['exam_date']; ?>">
                </div>

                <div class="col-md-6 mb-3">
                    <label>Duration (Minutes)</label>
                    <input type="number" name="examDuration" class="form-control"
                           value="<?php echo $row['duration_minutes']; ?>">
                </div>

                <div class="col-md-6 mb-3">
                    <label>Total Questions</label>
                    <input type="number" name="totalQuestions" class="form-control"
                           value="<?php echo $row['total_questions']; ?>">
                </div>

                <div class="col-md-6 mb-3">
                    <label>Exam Fee</label>
                    <input type="number" name="exam_fee" class="form-control"
                           value="<?php echo $row['exam_fee']; ?>">
                </div>

                <div class="col-md-12 mb-4">
                    <label>Description</label>
                    <textarea name="examDesc" class="form-control"><?php echo $row['exam_desc']; ?></textarea>
                </div>

            </div>

            <div class="d-flex gap-3">
                <button class="btn btn-custom btn-update">
                    Update Exam
                </button>

                <a href="examlist.php" class="btn btn-custom btn-back">
                    Back
                </a>
            </div>

        </form>

        <?php } else { ?>

            <div class="alert alert-danger text-center">
                Exam not found
            </div>

        <?php } ?>

    </div>

</div>

<?php include '../inc/footer.php'; ?>