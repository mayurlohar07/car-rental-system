<?php 
$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/inc/header.php');
include_once ($filepath.'/../classes/Exam.php');

$exam = new Exam();

if (!isset($_GET['que_id'])) {
    header("Location: queslist.php");
    exit();
}

$que_id = (int)$_GET['que_id'];

/* GET QUESTION DATA */
$data = $exam->getAnswerOptions($que_id);
$row = $data ? $data->fetch_assoc() : null;

/* UPDATE */
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $question = $_POST['question'];
    $option1  = $_POST['option1'];
    $option2  = $_POST['option2'];
    $option3  = $_POST['option3'];
    $option4  = $_POST['option4'];
    $answer   = $_POST['answer'];

    $update = $exam->updateQuestion($que_id, $question, $option1, $option2, $option3, $option4, $answer);
}
?>

<style>
body{
    background:linear-gradient(135deg,#eef2f7,#dfe9f3);
}

/* Main Box */
.edit-box{
    max-width:900px;
    margin:60px auto;
    background:#fff;
    border-radius:18px;
    padding:40px;
    box-shadow:0 15px 35px rgba(0,0,0,0.08);
}

/* Header */
.top-title{
    background:linear-gradient(135deg,#0d6efd,#6f42c1);
    color:#fff;
    padding:25px;
    border-radius:14px;
    text-align:center;
    margin-bottom:30px;
}

.top-title h2{
    margin:0;
    font-size:30px;
    font-weight:700;
}

.top-title p{
    margin:5px 0 0;
    opacity:.9;
}

/* Labels */
label{
    font-weight:600;
    margin-bottom:8px;
    color:#333;
}

/* Inputs */
.form-control{
    min-height:50px;
    border-radius:10px;
    border:1px solid #dcdcdc;
    padding-left:15px;
    font-size:15px;
}

.form-control:focus{
    border-color:#0d6efd;
    box-shadow:0 0 0 0.15rem rgba(13,110,253,.15);
}

/* Buttons */
.btn-custom{
    min-width:170px;
    height:48px;
    border:none;
    border-radius:10px;
    font-weight:600;
    transition:.3s;
}

.btn-update{
    background:#198754;
    color:#fff;
}

.btn-update:hover{
    background:#157347;
}

.btn-back{
    background:#6c757d;
    color:#fff;
}

.btn-back:hover{
    background:#5c636a;
}

.btn-custom:hover{
    transform:translateY(-2px);
}
</style>

<div class="container">

    <div class="edit-box">

        <div class="top-title">
            <h2>Edit Question</h2>
            <p>Update question and answer options</p>
        </div>

        <?php if (isset($update)) echo $update; ?>

        <?php if ($row) { ?>

        <form method="POST">

            <div class="mb-3">
                <label>Question</label>
                <input type="text" name="question" class="form-control"
                       value="<?php echo $row['question']; ?>" required>
            </div>

            <div class="row">

                <div class="col-md-6 mb-3">
                    <label>Option 1</label>
                    <input type="text" name="option1" class="form-control"
                           value="<?php echo $row['option1']; ?>" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label>Option 2</label>
                    <input type="text" name="option2" class="form-control"
                           value="<?php echo $row['option2']; ?>" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label>Option 3</label>
                    <input type="text" name="option3" class="form-control"
                           value="<?php echo $row['option3']; ?>" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label>Option 4</label>
                    <input type="text" name="option4" class="form-control"
                           value="<?php echo $row['option4']; ?>" required>
                </div>

            </div>

            <div class="mb-4">
                <label>Correct Answer</label>
                <input type="text" name="answer" class="form-control"
                       value="<?php echo $row['answer']; ?>" required>
            </div>

            <div class="d-flex gap-3">
                <button class="btn btn-custom btn-update">
                    Update Question
                </button>

                <a href="queslist.php" class="btn btn-custom btn-back">
                    Back
                </a>
            </div>

        </form>

        <?php } else { ?>

            <div class="alert alert-danger text-center">
                Question not found
            </div>

        <?php } ?>

    </div>

</div>

<?php include '../inc/footer.php'; ?>