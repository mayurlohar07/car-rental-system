<?php
$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/inc/header.php');
include_once ($filepath.'/../lib/Database.php');

$db = new Database();

/* PAYMENT HISTORY QUERY */
$query = "
SELECT 
p.id,
u.name,
u.email,
e.exam_name,
p.amount,
p.payment_status,
p.created_at
FROM tbl_payments p
INNER JOIN tbl_user u ON p.user_id = u.userid
INNER JOIN tbl_exam e ON p.exam_id = e.exam_id
ORDER BY p.id DESC
";

$result = $db->select($query);

/* TOTAL REVENUE */
$revenue = 0;
$total = $db->select("SELECT SUM(amount) AS total FROM tbl_payments WHERE payment_status='paid'");
if ($total) {
    $sum = $total->fetch_assoc();
    $revenue = $sum['total'];
}
?>

<style>
body{
    background:#f4f6f9;
}

/* Main Box */
.history-box{
    background:#fff;
    border-radius:18px;
    padding:35px;
    box-shadow:0 12px 30px rgba(0,0,0,0.08);
    margin-top:40px;
}

/* Header */
.top-title{
    background:linear-gradient(135deg,#0d6efd,#6f42c1);
    color:#fff;
    padding:30px;
    border-radius:15px;
    margin-bottom:30px;
    text-align:center;
}

.top-title h2{
    margin:0;
    font-size:30px;
    font-weight:700;
}

.top-title p{
    margin:5px 0 0;
    opacity:.9;
}

/* Revenue Card */
.revenue-card{
    background:#e8fff3;
    color:#198754;
    padding:20px;
    border-radius:14px;
    text-align:center;
    font-weight:700;
    margin-bottom:25px;
}

.revenue-card h3{
    margin:8px 0 0;
    font-size:28px;
}

/* Table */
.table{
    background:#fff;
    border-radius:12px;
    overflow:hidden;
}

.table thead{
    background:#0d6efd;
    color:#fff;
}

.table th, .table td{
    vertical-align:middle;
    padding:14px;
}

.badge-paid{
    background:#198754;
    color:#fff;
    padding:7px 12px;
    border-radius:20px;
    font-size:13px;
}

.badge-pending{
    background:#ffc107;
    color:#000;
    padding:7px 12px;
    border-radius:20px;
    font-size:13px;
}

.badge-failed{
    background:#dc3545;
    color:#fff;
    padding:7px 12px;
    border-radius:20px;
    font-size:13px;
}

.back-btn{
    border-radius:10px;
    padding:10px 18px;
    font-weight:600;
}
</style>

<div class="container">

    <div class="history-box">

        <div class="top-title">
            <h2>Payment History</h2>
            <p>Track all user payments and revenue</p>
        </div>

        <div class="revenue-card">
            Total Revenue
            <h3>₹<?php echo $revenue; ?></h3>
        </div>

        <div class="table-responsive">

            <table class="table table-bordered table-hover">

                <thead>
                    <tr>
                        <th>ID</th>
                        <th>User</th>
                        <th>Email</th>
                        <th>Exam</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>

                <tbody>

                <?php if ($result) { ?>

                    <?php while ($row = $result->fetch_assoc()) { ?>

                    <tr>
                        <td><?php echo $row['id']; ?></td>

                        <td><?php echo $row['name']; ?></td>

                        <td><?php echo $row['email']; ?></td>

                        <td><?php echo $row['exam_name']; ?></td>

                        <td>₹<?php echo $row['amount']; ?></td>

                        <td>
                            <?php
                            if ($row['payment_status'] == 'paid') {
                                echo "<span class='badge-paid'>Paid</span>";
                            } elseif ($row['payment_status'] == 'pending') {
                                echo "<span class='badge-pending'>Pending</span>";
                            } else {
                                echo "<span class='badge-failed'>Failed</span>";
                            }
                            ?>
                        </td>

                        <td><?php echo date("d M Y", strtotime($row['created_at'])); ?></td>
                    </tr>

                    <?php } ?>

                <?php } else { ?>

                    <tr>
                        <td colspan="7" class="text-center text-danger">
                            No Payment Records Found
                        </td>
                    </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

        <a href="index.php" class="btn btn-secondary back-btn mt-3">
            Back Dashboard
        </a>

    </div>

</div>

<?php include '../inc/footer.php'; ?>