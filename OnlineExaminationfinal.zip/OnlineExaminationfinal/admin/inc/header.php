<?php 
include_once ("../lib/Session.php");
Session::checkAdminSession();

include_once ("../lib/Database.php");
include_once ("../helpers/Format.php");

$db = new Database();
$fm = new Format();
?>

<?php
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: pre-check=0, post-check=0, max-age=0");
header("Pragma: no-cache");
header("Expires: Mon, 6 Dec 1977 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
?>

<!doctype html>
<html>
<head>
    <title>Admin</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/footer.css" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

<style>
body{
    background:#f4f6f9;
}

/* NAVBAR */
.navbar{
    background:#ffffff !important;
    padding:14px 0;
    box-shadow:0 6px 18px rgba(0,0,0,0.08);
    border-bottom:1px solid #ececec;
}

/* FULL WIDTH CONTAINER */
.navbar .container{
    max-width:95%;
}

/* BRAND LEFT PERFECT */
.navbar-brand{
    color:#111 !important;
    font-size:32px;
    font-weight:800;
    margin-right:35px;
    white-space:nowrap;
    min-width:290px;
}

/* RIGHT MENU */
.navbar-nav{
    align-items:center;
    flex-wrap:wrap;
    row-gap:10px;
}

.navbar-nav .nav-item{
    margin-left:8px;
}

/* SAME SIZE BUTTONS */
.navbar-nav .nav-link{
    color:#333 !important;
    font-weight:600;
    padding:12px 16px !important;
    border-radius:10px;
    transition:.3s ease;
    min-width:132px;
    height:46px;
    display:flex;
    align-items:center;
    justify-content:center;
    text-align:center;
    white-space:nowrap;
    font-size:14px;
}

.navbar-nav .nav-link:hover{
    transform:translateY(-2px);
    box-shadow:0 8px 18px rgba(0,0,0,0.08);
}

/* COLORS */
.home-btn{
    background:#e8f0ff;
    color:#0d6efd !important;
}

.users-btn{
    background:#e8fff3;
    color:#198754 !important;
}

.question-btn{
    background:#fff8e5;
    color:#d39e00 !important;
}

.exam-btn{
    background:#f3e8ff;
    color:#6f42c1 !important;
}

.result-btn{
    background:#e7fbff;
    color:#0dcaf0 !important;
}

.logout-btn{
    background:#dc3545;
    color:#fff !important;
    min-width:115px;
}

.logout-btn:hover{
    background:#bb2d3b !important;
}

/* MOBILE */
.navbar-toggler{
    border:none;
}

.navbar-toggler:focus{
    outline:none;
    box-shadow:none;
}

@media(max-width:991px){

    .navbar-brand{
        min-width:auto;
        font-size:26px;
        margin-right:0;
    }

    .navbar-nav{
        margin-top:15px;
    }

    .navbar-nav .nav-item{
        margin-left:0;
        margin-bottom:10px;
    }

    .navbar-nav .nav-link{
        width:100%;
    }
}
</style>

</head>

<body>

<?php
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    Session::destroy();
    header("Location:login.php");
    exit();
}
?>

<nav class="navbar navbar-expand-lg navbar-light static-top">

    <div class="container">

        <a class="navbar-brand" href="index.php">
            Online Examination
        </a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-end" id="navbarResponsive">

            <ul class="navbar-nav">

                <li class="nav-item">
                    <a class="nav-link home-btn" href="index.php">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link users-btn" href="users.php">Users</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link question-btn" href="quesadd.php">Add Question</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link exam-btn" href="examadd.php">Add Exam</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link exam-btn" href="examlist.php">Manage Exams</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link question-btn" href="queslist.php">Questions</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link result-btn" href="resultlist.php">Results</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link result-btn" href="paymenthistory.php">Payments</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link logout-btn" href="?action=logout">Logout</a>
                </li>

            </ul>

        </div>

    </div>

</nav>