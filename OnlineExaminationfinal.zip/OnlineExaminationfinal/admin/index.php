<?php
$filepath = realpath(dirname(__FILE__));
include_once($filepath . '../inc/header.php');

// ================== SAFE DATABASE CONNECTION ==================
$conn = null;

if (!isset($conn) || $conn === null) {
    $conn = mysqli_connect("localhost", "root", "", "mcqexamination");
    if (!$conn) {
        die("<div class='alert alert-danger p-4'>Database Connection Failed: " . mysqli_connect_error() . "</div>");
    }
}

// =============== REAL DATA FROM DATABASE ===============
$total_students = 0;
$total_exams    = 0;
$total_questions = 0;
$total_revenue  = 0.00;
$active_exams   = 0;

// Total Students
$sql = "SELECT COUNT(*) as total FROM tbl_user";
$result = mysqli_query($conn, $sql);
if($row = mysqli_fetch_assoc($result)) $total_students = $row['total'] ?? 0;

// Total Exams
$sql = "SELECT COUNT(*) as total FROM tbl_exam";
$result = mysqli_query($conn, $sql);
if($row = mysqli_fetch_assoc($result)) $total_exams = $row['total'] ?? 0;

// Active Exams
$sql = "SELECT COUNT(*) as active FROM tbl_exam WHERE status = 'active'";
$result = mysqli_query($conn, $sql);
if($row = mysqli_fetch_assoc($result)) $active_exams = $row['active'] ?? 0;

// Total Questions
$sql = "SELECT COUNT(*) as total FROM tbl_qands";
$result = mysqli_query($conn, $sql);
if($row = mysqli_fetch_assoc($result)) $total_questions = $row['total'] ?? 0;

// Total Revenue (paid only)
$sql = "SELECT SUM(amount) as revenue FROM tbl_payments WHERE payment_status = 'paid'";
$result = mysqli_query($conn, $sql);
if($row = mysqli_fetch_assoc($result)) $total_revenue = $row['revenue'] ?? 0;
?>

<style>
    body { background: #f4f6f9; }
    .dashboard-box {
        background: #ffffff;
        border-radius: 18px;
        padding: 30px;
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.08);
    }
    .top-title {
        background: linear-gradient(135deg, #0d6efd, #6f42c1);
        color: #fff;
        padding: 35px;
        border-radius: 16px;
        text-align: center;
        margin-bottom: 35px;
    }
    .stat-card {
        border: none;
        border-radius: 14px;
        padding: 25px 20px;
        color: white;
        transition: all 0.3s ease;
        height: 100%;
    }
    .stat-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 15px 25px rgba(0,0,0,0.15);
    }
    .stat-icon {
        font-size: 32px;
        opacity: 0.9;
    }
</style>

<div class="container mt-4 mb-5">
    <div class="dashboard-box">

        <!-- Top Title -->
        <div class="top-title">
            <h1>Exam Control Panel</h1>
            <p>Professional Admin Dashboard</p>
        </div>

        <!-- Statistics Cards (Real Data) -->
        <div class="row g-4">
            <div class="col-lg-3 col-md-6">
                <div class="stat-card" style="background: linear-gradient(135deg, #198754, #20c997);">
                    <i class="fas fa-users stat-icon"></i>
                    <h4 class="mt-3">Total Students</h4>
                    <h2><?= number_format($total_students) ?></h2>
                    <small>Registered Users</small>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="stat-card" style="background: linear-gradient(135deg, #fd7e14, #ffc107);">
                    <i class="fas fa-file-alt stat-icon"></i>
                    <h4 class="mt-3">Total Exams</h4>
                    <h2><?= number_format($total_exams) ?></h2>
                    <small><?= $active_exams ?> Active</small>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="stat-card" style="background: linear-gradient(135deg, #0d6efd, #4e73df);">
                    <i class="fas fa-question-circle stat-icon"></i>
                    <h4 class="mt-3">Total Questions</h4>
                    <h2><?= number_format($total_questions) ?></h2>
                    <small>MCQs in System</small>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="stat-card" style="background: linear-gradient(135deg, #e74c3c, #dc3545);">
                    <i class="fas fa-rupee-sign stat-icon"></i>
                    <h4 class="mt-3">Total Revenue</h4>
                    <h2>₹<?= number_format($total_revenue, 2) ?></h2>
                    <small>From Paid Exams</small>
                </div>
            </div>
        </div>

    </div>
</div>

<?php include '../inc/footer.php'; ?>