<?php
$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/inc/header.php');
include_once ($filepath.'/../lib/Database.php');

$db = new Database();
?>

<style>
body{
    background:#f4f6f9;
}
.list-box{
    background:#ffffff;
    padding:35px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    margin-top:40px;
    margin-bottom:40px;
}
.page-title{
    background:linear-gradient(135deg,#198754,#20c997);
    color:#fff;
    padding:25px;
    border-radius:12px;
    text-align:center;
    margin-bottom:30px;
}
.page-title h1{
    margin:0;
    font-size:32px;
    font-weight:700;
}
.table thead{
    background:#212529;
    color:#fff;
}
.table td,
.table th{
    vertical-align:middle;
    text-align:center;
}
.table tbody tr:hover{
    background:#f8f9fa;
}
.badge-paid{
    background:#198754;
    color:#fff;
    padding:6px 12px;
    border-radius:20px;
    font-size:13px;
}
.badge-pending{
    background:#ffc107;
    color:#000;
    padding:6px 12px;
    border-radius:20px;
    font-size:13px;
}
</style>

<div class="container">

    <div class="list-box">

        <div class="page-title">
            <h1>Payment List</h1>
        </div>

        <div class="table-responsive">

            <table class="table table-bordered table-hover table-striped">

                <thead>
                    <tr>
                        <th width="5%">#</th>
                        <th width="10%">User ID</th>
                        <th width="18%">Student Name</th>
                        <th width="10%">Exam ID</th>
                        <th width="18%">Exam Name</th>
                        <th width="12%">Amount</th>
                        <th width="12%">Payment ID</th>
                        <th width="10%">Status</th>
                        <th width="15%">Date</th>
                    </tr>
                </thead>

                <tbody>

                <?php
                $query = "
                    SELECT p.*, e.exam_name
                    FROM tbl_payments p
                    LEFT JOIN tbl_exam e ON p.exam_id = e.exam_id
                    ORDER BY p.id DESC
                ";

                $paymentData = $db->select($query);

                if ($paymentData) {

                    $i = 0;

                    while ($result = $paymentData->fetch_assoc()) {

                        $i++;

                        $status = strtolower($result['payment_status']);
                ?>

                    <tr>

                        <td><?php echo $i; ?></td>

                        <td><?php echo $result['user_id']; ?></td>

                        <td><?php echo $result['username']; ?></td>

                        <td><?php echo $result['exam_id']; ?></td>

                        <td><?php echo $result['exam_name']; ?></td>

                        <td>
                            ₹<?php echo number_format($result['amount'],2); ?>
                        </td>

                        <td>
                            <?php echo $result['payment_id']; ?>
                        </td>

                        <td>

                            <?php if($status == 'paid'){ ?>

                                <span class="badge-paid">Paid</span>

                            <?php } else { ?>

                                <span class="badge-pending">
                                    <?php echo ucfirst($status); ?>
                                </span>

                            <?php } ?>

                        </td>

                        <td>
                            <?php echo $result['created_at']; ?>
                        </td>

                    </tr>

                <?php
                    }
                }
                else{
                ?>

                    <tr>
                        <td colspan="9">No Payments Found</td>
                    </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php include '../inc/footer.php'; ?>