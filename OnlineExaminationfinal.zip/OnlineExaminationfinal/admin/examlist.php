<?php
$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/inc/header.php');
include_once ($filepath.'/../classes/Exam.php');
$exam = new Exam();
?>

<?php
if (isset($_GET['delexam'])) {
    $exam_id = (int)$_GET['delexam'];
    $delresult = $exam->getDelExam($exam_id);
}
?>

<style>
body{
    background:#f4f6f9;
}
.list-box{
    background:#ffffff;
    padding:35px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    margin-top:40px;
    margin-bottom:40px;
}
.page-title{
    background:linear-gradient(135deg,#198754,#20c997);
    color:#fff;
    padding:25px;
    border-radius:12px;
    text-align:center;
    margin-bottom:30px;
}
.page-title h1{
    margin:0;
    font-size:32px;
    font-weight:700;
}
.table thead{
    background:#212529;
    color:#fff;
}
.table td,
.table th{
    vertical-align:middle;
    text-align:center;
}
.table tbody tr:hover{
    background:#f8f9fa;
}
.badge-fee{
    background:#198754;
    color:#fff;
    padding:7px 12px;
    border-radius:20px;
    font-size:14px;
}
.btn-remove{
    padding:7px 18px;
    border-radius:8px;
}
</style>

<div class="container">

    <div class="list-box">

        <?php
        if (isset($delresult)) {
            echo $delresult;
        }
        ?>

        <div class="page-title">
            <h1>Manage Exams</h1>
        </div>

        <div class="table-responsive">

            <table class="table table-bordered table-hover table-striped">

                <thead>
                    <tr>
                        <th width="5%">#</th>
                        <th width="15%">Exam Name</th>
                        <th width="22%">Description</th>
                        <th width="12%">Date</th>
                        <th width="10%">Duration</th>
                        <th width="10%">Questions</th>
                        <th width="11%">Fees</th>
                        <th width="15%">Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php
                $examData = $exam->getAllExams();

                if ($examData) {
                    $i = 0;

                    while ($result = $examData->fetch_assoc()) {
                        $i++;

                        $fees = isset($result['exam_fee']) ? $result['exam_fee'] : 0;
                ?>

                    <tr>
                        <td><?php echo $i; ?></td>

                        <td>
                            <strong><?php echo $result['exam_name']; ?></strong>
                        </td>

                        <td><?php echo $result['exam_desc']; ?></td>

                        <td><?php echo $result['exam_date']; ?></td>

                        <td>
                            <?php echo $result['duration_minutes']; ?> Min
                        </td>

                        <td>
                            <?php echo $result['total_questions']; ?>
                        </td>

                        <td>
                            <span class="badge-fee">
                                ₹<?php echo $fees; ?>
                            </span>
                        </td>

                      <td>

    <a class="btn btn-primary btn-sm"
       href="editexam.php?id=<?php echo $result['exam_id']; ?>">
       <i class="fa fa-edit"></i> Edit
    </a>

    <a class="btn btn-danger btn-sm"
       onclick="return confirm('Are you sure to Delete this Exam?')"
       href="?delexam=<?php echo $result['exam_id']; ?>">
       Remove
    </a>

</td>
                    </tr>

                <?php } } ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php include '../inc/footer.php'; ?>