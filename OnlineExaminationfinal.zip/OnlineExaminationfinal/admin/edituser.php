<?php 
$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/inc/header.php');
include_once ($filepath.'/../classes/User.php');

$user = new User();

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: users.php");
    exit();
}

$id = (int) $_GET['id'];

$userData = $user->getUserProfile($id);

$row = null;
if ($userData) {
    $row = $userData->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $update = $user->getUserPData($id, $_POST);
}
?>

<style>
body{
    background: linear-gradient(135deg,#eef2f7,#dfe9f3);
}

/* Main Card */
.edit-box{
    max-width:700px;
    margin:60px auto;
    background:#ffffff;
    border-radius:18px;
    padding:40px;
    box-shadow:0 15px 35px rgba(0,0,0,0.08);
}

/* Header */
.top-title{
    background:linear-gradient(135deg,#0d6efd,#6f42c1);
    color:#fff;
    padding:25px;
    border-radius:14px;
    text-align:center;
    margin-bottom:30px;
}

.top-title h2{
    margin:0;
    font-weight:700;
    font-size:30px;
}

.top-title p{
    margin:5px 0 0;
    opacity:.9;
}

/* Labels */
label{
    font-weight:600;
    margin-bottom:8px;
    color:#333;
}

/* Inputs */
.form-control{
    height:50px;
    border-radius:10px;
    border:1px solid #dcdcdc;
    padding-left:15px;
    font-size:15px;
}

.form-control:focus{
    border-color:#0d6efd;
    box-shadow:0 0 0 0.15rem rgba(13,110,253,.15);
}

/* Buttons */
.btn-custom{
    min-width:150px;
    height:48px;
    border:none;
    border-radius:10px;
    font-weight:600;
    transition:0.3s;
}

.btn-update{
    background:#198754;
    color:#fff;
}

.btn-update:hover{
    background:#157347;
}

.btn-back{
    background:#6c757d;
    color:#fff;
}

.btn-back:hover{
    background:#5c636a;
}

.btn-custom:hover{
    transform:translateY(-2px);
}
</style>

<div class="container">

    <div class="edit-box">

        <div class="top-title">
            <h2>Edit User</h2>
            <p>Update user profile details</p>
        </div>

        <?php 
        if (isset($update)) {
            echo $update;
        }
        ?>

        <?php if ($row) { ?>

        <form method="post">

            <div class="mb-3">
                <label>Name</label>
                <input type="text" name="name" class="form-control"
                       value="<?php echo $row['name']; ?>" required>
            </div>

            <div class="mb-3">
                <label>Username</label>
                <input type="text" name="userName" class="form-control"
                       value="<?php echo $row['userName']; ?>" required>
            </div>

            <div class="mb-4">
                <label>Email</label>
                <input type="text" name="email" class="form-control"
                       value="<?php echo $row['email']; ?>" required>
            </div>

            <div class="d-flex gap-3">
                <button class="btn btn-custom btn-update">
                    Update User
                </button>

                <a href="users.php" class="btn btn-custom btn-back">
                    Back
                </a>
            </div>

        </form>

        <?php } else { ?>

            <div class="alert alert-danger text-center">
                User not found
            </div>

        <?php } ?>

    </div>

</div>

<?php include '../inc/footer.php'; ?>