<?php include 'inc/header.php'; ?>
<?php
Session::checkSession();
?>

<style>
body{
    background:#f4f6f9;
}
.select-box{
    background:#ffffff;
    padding:50px 40px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    margin-top:60px;
    margin-bottom:60px;
}
.page-title{
    background:linear-gradient(135deg,#28a745,#20c997);
    color:#fff;
    padding:30px;
    border-radius:12px;
    margin-bottom:30px;
}
.page-title h1{
    margin:0;
    font-size:34px;
    font-weight:700;
}
.page-title p{
    margin-top:10px;
    font-size:17px;
    opacity:.95;
}
.exam-img{
    margin:20px 0;
}
.btn-start{
    padding:14px 35px;
    font-size:20px;
    border-radius:10px;
    transition:.3s;
}
.btn-start:hover{
    transform:translateY(-3px);
}
.info-box{
    background:#f8f9fa;
    padding:18px;
    border-radius:10px;
    margin-top:25px;
    color:#555;
    font-size:15px;
}
</style>

<div class="container">

    <div class="row justify-content-center">

        <div class="col-lg-8 text-center">

            <div class="select-box">

                <div class="page-title">
                    <h1>You Can Select Your Exam</h1>
                    <p>Choose your exam, complete payment and start instantly.</p>
                </div>

                <img src="img/takeTest.png" height="200" width="200" class="exam-img"/>

                <br><br>

                <!-- SAME LOGIC -->
                <a href="starttest.php" class="btn btn-success btn-lg btn-start">
                    <span class="fa fa-arrow-right"></span>
                    Select Exam Now!
                </a>

                <div class="info-box">
                    After selecting exam, if fee is applicable then payment page will open automatically.
                </div>

            </div>

        </div>

    </div>

</div>

<?php include 'inc/footer.php'; ?>  