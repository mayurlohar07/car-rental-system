<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "mcqexamination");



/* Razorpay Keys */
define("RAZORPAY_KEY_ID", "rzp_test_SevwdxJ58za5c0");
define("RAZORPAY_KEY_SECRET", "iJtbFl0ODoh7xTPvPvcCDykS");
