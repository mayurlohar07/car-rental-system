<?php include 'inc/header.php'; ?>
<?php
Session::checkSession();

// ---------------------------
// GET EXAM ID
// ---------------------------
if (isset($_GET['exam_id'])) {
    $exam_id = (int) $_GET['exam_id'];
    Session::set("exam_id", $exam_id);
} else {
    $exam_id = Session::get("exam_id");
}

// ---------------------------
// PAYMENT CHECK
// ---------------------------
$user_id = Session::get("userId");

$payCheck = $db->select("
    SELECT id FROM tbl_payments 
    WHERE user_id='$user_id' 
    AND exam_id='$exam_id' 
    AND payment_status='paid'
    LIMIT 1
");

if (!$payCheck) {
    header("Location: starttest.php?pay=required");
    exit();
}

// ---------------------------
// EXAM TIMER
// ---------------------------
$queryExam = "SELECT duration_minutes FROM tbl_exam WHERE exam_id = '$exam_id'";
$examData = $db->select($queryExam)->fetch_assoc();

$duration_minutes = $examData['duration_minutes'] ?? 1;
$duration_seconds = $duration_minutes * 60;

if (!Session::get("exam_start_time")) {
    Session::set("exam_start_time", time());
}

$start_time = Session::get("exam_start_time");
$remaining_time = ($start_time + $duration_seconds) - time();

// ---------------------------
// TIME OUT CHECK
// ---------------------------
if ($remaining_time <= 0) {

    $saved_answers = Session::get("saved_answers") ?? [];
    $score = 0;

   $saved_answers = Session::get("saved_answers");

if (!is_array($saved_answers)) {
    $saved_answers = [];
}

foreach ($saved_answers as $qnum => $ans) {
    // your logic
}

    $_SESSION['score'] = $score;

    header("Location: final.php?timeout=1");
    exit();
}

// ---------------------------
// QUESTION NUMBER
// ---------------------------
$ques_number = isset($_GET['q']) ? (int)$_GET['q'] : 1;
if ($ques_number < 1) $ques_number = 1;

// ---------------------------
// GET TOTAL QUESTIONS
// ---------------------------
$total = $exam->getTotalRows($exam_id);

// ---------------------------
// GET QUESTION
// ---------------------------
$question = $exam->getQuestionNumber($exam_id, $ques_number);

if (!$question) {
    header("Location: final.php");
    exit();
}

// ---------------------------
// HANDLE FORM SUBMIT
// ---------------------------
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // LOAD OLD SESSION DATA FIRST
    $saved_answers = Session::get("saved_answers");
    $saved_answers = is_array($saved_answers) ? $saved_answers : [];

    // SAVE ANSWER
    if (isset($_POST['ans'], $_POST['quesnumber'])) {
        $saved_answers[(int)$_POST['quesnumber']] = (int)$_POST['ans'];
        Session::set("saved_answers", $saved_answers);
    }

    // FINISH EXAM
    if (isset($_POST['finish_exam'])) {

        $score = 0;

        foreach ($saved_answers as $qnum => $ans) {
            $q = $exam->getQuestionNumber($exam_id, $qnum);

            if ($q && $q['answer'] == $ans) {
                $score++;
            }
        }

        $_SESSION['score'] = $score;

        header("Location: final.php");
        exit();
    }

    // NEXT QUESTION
    if (isset($_POST['submit'])) {

        $process = $pro->getProcessData($_POST);

        $next = $ques_number + 1;

        if ($next > $total) {
            header("Location: final.php");
            exit();
        } else {
            header("Location: test.php?q=$next&exam_id=$exam_id");
            exit();
        }
    }
}

// ---------------------------
// LOAD SAVED ANSWER
// ---------------------------
$saved_answers = Session::get("saved_answers");
$saved_answers = is_array($saved_answers) ? $saved_answers : [];

$current_saved_ans = $saved_answers[$ques_number] ?? null;
?>

<!-- ===== UI SAME AS YOUR DESIGN ===== -->

<style>
body{background:#f4f6f9;}
.exam-box{background:#fff;padding:40px;border-radius:15px;box-shadow:0 10px 25px rgba(0,0,0,0.08);margin-top:50px;}
.timer-box{background:#fff3cd;padding:15px;border-radius:10px;font-size:24px;font-weight:700;color:#dc3545;margin-bottom:25px;}
.question-title{background:linear-gradient(135deg,#007bff,#6610f2);color:#fff;padding:20px;border-radius:12px;margin-bottom:25px;}
.option-box{border:1px solid #e5e5e5;padding:15px;border-radius:10px;margin-bottom:12px;}
.option-box:hover{background:#f8f9fa;}
.btn-custom{padding:12px 30px;font-size:17px;border-radius:10px;}
</style>

<div class="container">
<div class="row justify-content-center">
<div class="col-lg-8">

<div class="exam-box text-center">

<div class="timer-box">
⏱ Time Left: <span id="timer"></span>
</div>

<div class="question-title">
<h2>Question <?php echo $ques_number . " of " . $total; ?></h2>
</div>

<form method="post">

<h4 class="mb-4 text-left">
<?php echo "Q".$ques_number.": ".$question['question']; ?>
</h4>

<?php for ($i=1; $i<=4; $i++) { ?>

<div class="option-box text-left">
<label class="w-100">

<input type="radio"
name="ans"
value="<?php echo $i; ?>"
<?php echo ($current_saved_ans == $i) ? 'checked' : ''; ?>
required>

<?php echo $question['option'.$i]; ?>

</label>
</div>

<?php } ?>

<input type="hidden" name="quesnumber" value="<?php echo $ques_number; ?>">
<input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">

<br>

<input type="submit" name="submit" class="btn btn-primary btn-custom" value="Continue">
<button type="submit" name="finish_exam" class="btn btn-danger btn-custom">Submit Exam</button>

</form>

</div>
</div>
</div>
</div>

<script>
let timeLeft = <?php echo $remaining_time; ?>;

setInterval(() => {
    let m = Math.floor(timeLeft / 60);
    let s = timeLeft % 60;

    document.getElementById("timer").innerHTML = m + "m " + (s<10?"0"+s:s);

    timeLeft--;

    if(timeLeft < 0){
        window.location.href = "final.php?timeout=1";
    }

},1000);
</script>

<?php include 'inc/footer.php'; ?>