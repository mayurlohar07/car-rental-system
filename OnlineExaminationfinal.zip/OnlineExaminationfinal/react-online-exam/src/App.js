import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import './css/main.css';
import './css/footer.css';
import Login from './pages/Login';
import Register from './pages/Register';
import AdminLogin from './pages/AdminLogin';
import Exam from './pages/Exam';
import Profile from './pages/Profile';
import Test from './pages/Test';
import Final from './pages/Final';
import ViewAns from './pages/ViewAns';
import AdminHome from './pages/AdminHome';
import ManageUsers from './pages/ManageUsers';
import AddQuestion from './pages/AddQuestion';
import ManageQuestions from './pages/ManageQuestions';
import AddExam from './pages/addexam.jsx';
import ExamList from './pages/ExamList.jsx';
import StartTest from './pages/StartTest';
import StartExam from "./pages/StartExam";
import ViewResult from './pages/ViewResult';
function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState('');
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserName('');
    setIsAdminLoggedIn(false);
  };

  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<Login setLogin={setIsLoggedIn} setUserName={setUserName} />} />
          <Route path="/register" element={<Register />} />
          <Route path="/starttest" element={<StartTest isLoggedIn={isLoggedIn} userName={userName} onLogout={handleLogout} />} />
          <Route path="/exam" element={<Exam isLoggedIn={isLoggedIn} userName={userName} onLogout={handleLogout} />} />
          <Route path="/profile" element={<Profile isLoggedIn={isLoggedIn} userName={userName} onLogout={handleLogout} />} />
          <Route path="/test/:q" element={<Test isLoggedIn={isLoggedIn} userName={userName} onLogout={handleLogout} />} />
          <Route path="/final" element={<Final isLoggedIn={isLoggedIn} userName={userName} onLogout={handleLogout} />} />
          <Route path="/viewans" element={<ViewAns isLoggedIn={isLoggedIn} userName={userName} onLogout={handleLogout} />} />
          <Route path="/admin" element={<AdminLogin setAdminLogin={setIsAdminLoggedIn} />} />
          <Route path="/adminhome" element={<AdminHome isAdminLoggedIn={isAdminLoggedIn} onLogout={handleLogout} />} />
          <Route path="/manageusers" element={<ManageUsers isAdminLoggedIn={isAdminLoggedIn} onLogout={handleLogout} />} />
          <Route path="/addexam" element={<AddExam isAdminLoggedIn={isAdminLoggedIn} onLogout={handleLogout} />} />
          <Route path="/examlist" element={<ExamList isAdminLoggedIn={isAdminLoggedIn} onLogout={handleLogout} />} />
          <Route path="/addquestion" element={<AddQuestion isAdminLoggedIn={isAdminLoggedIn} onLogout={handleLogout} />} />
          <Route path="/start-exam/:exam_id" element={<StartExam />} />
          <Route path="/view-results" element={<ViewResult />} />
          <Route path="/managequestions" element={<ManageQuestions isAdminLoggedIn={isAdminLoggedIn} onLogout={handleLogout} />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
