import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Header = ({ isLoggedIn, userName, onLogout, isAdmin }) => {

  const navigate = useNavigate();

  const handleLogout = () => {
    onLogout();                   // clear login state from parent
    localStorage.clear();         // clear admin data
    navigate("/admin");           // redirect to admin login page
  };

  // ─────────────────────────────
  // ADMIN LOGOUT VIEW (NOT LOGGED IN)
  // ─────────────────────────────
  if (isAdmin && !isLoggedIn) {
    return (
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark static-top">
        <div className="container">
          <Link className="navbar-brand" to="/admin">Admin Login</Link>
        </div>
      </nav>
    );
  }

  // ─────────────────────────────
  // ADMIN DASHBOARD HEADER
  // ─────────────────────────────
  if (isAdmin && isLoggedIn) {
    return (
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark static-top">
        <div className="container">
          <Link className="navbar-brand" to="/adminhome">Online Examination System - Admin</Link>

          <button className="navbar-toggler" type="button" data-toggle="collapse"
            data-target="#navbarResponsive" aria-controls="navbarResponsive"
            aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse" id="navbarResponsive">
            <ul className="navbar-nav ml-auto">

              <li className="nav-item"><Link className="nav-link" to="/adminhome">Home</Link></li>
              <li className="nav-item"><Link className="nav-link" to="/manageusers">Manage Users</Link></li>
              <li className="nav-item"><Link className="nav-link" to="/addquestion">Add Question</Link></li>
              <li className="nav-item"><Link className="nav-link" to="/managequestions">Manage Questions</Link></li>
              <li className="nav-item"><Link className="nav-link" to="/addexam">Add Exam</Link></li>
              <li className="nav-item"><Link className="nav-link" to="/examlist">Manage Exam</Link></li>
              <li className="nav-item"><Link className="nav-link" to="/view-results">View Results</Link></li>

              <li className="nav-item">
                <button className="nav-link btn btn-link" onClick={handleLogout}>
                  Logout
                </button>
              </li>

            </ul>
          </div>
        </div>
      </nav>
    );
  }

  // ─────────────────────────────
  // REGULAR USER HEADER
  // ─────────────────────────────
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark static-top">
      <div className="container">
        <Link className="navbar-brand" to="/">Online Examination System</Link>

        <button className="navbar-toggler" type="button" data-toggle="collapse"
          data-target="#navbarResponsive" aria-controls="navbarResponsive"
          aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarResponsive">
          <ul className="navbar-nav ml-auto">

            {isLoggedIn ? (
              <>
                <li className="nav-item active">
                  <span className="nav-link">
                    Welcome <strong>{userName}</strong>
                  </span>
                </li>

                <li className="nav-item"><Link className="nav-link" to="/profile">Profile</Link></li>
                <li className="nav-item"><Link className="nav-link" to="/exam">Exam</Link></li>

                <li className="nav-item">
                  <button className="nav-link btn btn-link" onClick={handleLogout}>
                    Logout
                  </button>
                </li>
              </>
            ) : (
              <>
                <li className="nav-item"><Link className="nav-link" to="/">Login</Link></li>
                <li className="nav-item"><Link className="nav-link" to="/register">Register</Link></li>
                <li className="nav-item"><Link className="nav-link" to="/admin">Admin</Link></li>
              </>
            )}

          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Header;
