import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const ManageQuestions = ({ isAdminLoggedIn, onLogout }) => {
  const [questions, setQuestions] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetch('http://localhost/OnlineExamination-PHP/api/getAllQuestions.php')
      .then(response => response.json())
      .then(data => setQuestions(data.questions || []))
      .catch(err => console.error('Error fetching questions:', err));
  }, []);

  const handleDelete = (que_id) => {
    if (window.confirm('Are you sure you want to delete this question?')) {
      fetch(`http://localhost/OnlineExamination-PHP/api/deleteQuestionDB.php?que_id=${que_id}`, {
        method: 'DELETE',
      })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            setQuestions(questions.filter(q => q.que_id !== que_id));
            setMessage('Question deleted successfully.');
          } else {
            setMessage('Failed to delete question.');
          }
        })
        .catch(err => {
          console.error('Error deleting question:', err);
          setMessage('Error deleting question.');
        });
    }
  };

  return (
    <>
      <Header isLoggedIn={false} userName="" onLogout={onLogout} isAdmin={true} />

      <div className="container">
        <div className="row">

          <div className="col-lg-12 text-center">
            {message && <div>{message}</div>}
            <h1 className="mt-5">Question List</h1>
            <br />
          </div>

          <div className="col-lg-12">
            <table className="table table-striped table-bordered table-hover">
              <thead className="table-dark">
                <tr>
                  <th>#</th>
                  <th>Question</th>
                  <th>Exam ID</th>
                  <th>Question No</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {questions.map((q, index) => (
                  <tr key={q.que_id}>
                    <td>{index + 1}</td>
                    <td>{q.question}</td>
                    <td>{q.exam_id}</td>
                    <td>{q.ques_number}</td>
                    <td>
                      <button
                        className="btn btn-danger"
                        onClick={() => handleDelete(q.que_id)}
                      >
                        Remove
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>

            </table>
          </div>

        </div>
      </div>

      <Footer />
    </>
  );
};

export default ManageQuestions;
