import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';

const StartTest = ({ isLoggedIn, userName, onLogout }) => {
  const [totalQuestions, setTotalQuestions] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoggedIn) {
      navigate('/');
      return;
    }

    // Fetch total questions from questions.json
    fetch('/questions.json')
      .then(response => response.json())
      .then(data => {
        setTotalQuestions(data.length);
      })
      .catch(error => {
        console.error('Error fetching questions:', error);
      });
  }, [isLoggedIn, navigate]);

  const handleProceed = () => {
    if (totalQuestions > 0) {
      navigate(`/test/1`);
    }
  };

  return (
    <>
      <Header isLoggedIn={isLoggedIn} userName={userName} onLogout={onLogout} />
      <div className="container">
        <div className="row">
          <div className="col-lg-12 text-center">
            <h1 className="mt-5">Welcome to Online Examination</h1>
            <p className="lead">Test Your Knowledge</p>
            <br />
            <p className="lead">
              Total Number Of Question: <b>{totalQuestions}</b>
            </p>
            <p><strong>Question Type:</strong> Multiple Choice (MCQ)</p>
            <button className="btn btn-success btn-lg" onClick={handleProceed}>
              <span className="fa fa-arrow-right"></span> Proceed
            </button>
            <br />
            <br />
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default StartTest;
