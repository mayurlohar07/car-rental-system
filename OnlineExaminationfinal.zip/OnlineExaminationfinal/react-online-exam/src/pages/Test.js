import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Test = ({ isLoggedIn, userName, onLogout }) => {
  const { q } = useParams();
  const navigate = useNavigate();
  const quesnumber = parseInt(q);
  const [question, setQuestion] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [total, setTotal] = useState(0);
  const [selectedAns, setSelectedAns] = useState('');
  // Remove local isLoggedInState, use prop directly
  const [error, setError] = useState('');

  useEffect(() => {
    // Check if user is logged in, if not redirect to login page
    if (!isLoggedIn) {
      navigate('/');
      return;
    }

    // Fetch total questions
    fetch('http://localhost/api/getTotalQuestions.php')
      .then(response => {
        if (!response.ok) {
          throw new Error(`Network response was not ok: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        if (data.error) {
          setError(`Error fetching total questions: ${data.error}`);
        } else {
          setTotal(data.total);
        }
      })
      .catch(err => {
        console.error('Error fetching total:', err);
        setError(`Error fetching total questions: ${err.message}`);
      });

    // Fetch question and answers
    fetch(`http://localhost/api/getQuestion.php?q=${quesnumber}`)
      .then(response => {
        if (!response.ok) {
          throw new Error(`Network response was not ok: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        if (data.error) {
          console.error('API error:', data.error);
          setError(`API error: ${data.error}`);
          setQuestion(null);
          setAnswers([]);
        } else {
          setQuestion(data.question);
          setAnswers(data.answers);
          setError(''); // Clear error if successful
        }
      })
      .catch(err => {
        console.error('Error fetching question:', err);
        setError(`Error fetching question: ${err.message}`);
        setQuestion(null);
        setAnswers([]);
      });
  }, [quesnumber, isLoggedIn, navigate]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('ans', selectedAns);
    formData.append('quesnumber', quesnumber);

    fetch('/test.php', {
      method: 'POST',
      body: formData,
    })
      .then(response => {
        if (quesnumber < total) {
          navigate(`/test/${quesnumber + 1}`);
        } else {
          navigate('/final');
        }
      })
      .catch(err => console.error('Error submitting answer:', err));
  };

  if (!question) return <div>Loading...</div>;

  return (
    <>
      <Header isLoggedIn={isLoggedIn} userName={userName} onLogout={onLogout} />
      <div className="container">
        <div className="row">
          <div className="col-lg-12 text-center">
            <h1 className="mt-5">Question {question.quesNo} of {total}</h1>
            <br />
            <br />
          </div>

          <div className="col-lg-3"></div>

          <div className="col-lg-6">
            <form onSubmit={handleSubmit}>
              <table>
                <tr>
                  <td colSpan="2">
                    <h3>Question {question.quesNo} : {question.ques}</h3>
                  </td>
                </tr>
                {answers.map((ans) => (
                  <tr key={ans.id}>
                    <td>
                      <div className="form-check">
                        <label className="form-check-label">
                          <input
                            type="radio"
                            name="ans"
                            className="form-check-input"
                            value={ans.id}
                            checked={selectedAns === ans.id.toString()}
                            onChange={(e) => setSelectedAns(e.target.value)}
                            required
                          />
                          {ans.ans}
                        </label>
                      </div>
                    </td>
                  </tr>
                ))}
                <tr>
                  <td>
                    <br />
                    <button type="submit" className="btn btn-primary">Continue</button>
                  </td>
                </tr>
              </table>
            </form>
            <br />
            <br />
          </div>

          <div className="col-lg-3"></div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Test;
