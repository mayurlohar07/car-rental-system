import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';

const ExamList = ({ isAdminLoggedIn, onLogout }) => {
  const [exams, setExams] = useState([]);
  const [message, setMessage] = useState('');
  const [msgType, setMsgType] = useState('');
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAdminLoggedIn) {
      navigate('/admin');
      return;
    }

    // Fetch exams from API
    fetch('/api/getAllExams.php')
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          setExams(data.exams);
        }
        setLoading(false);
      })
      .catch(err => {
        console.error('Error fetching exams:', err);
        setLoading(false);
      });
  }, [isAdminLoggedIn, navigate]);

  const handleDelete = (examId) => {
    if (window.confirm('Are you sure to Delete this Exam?')) {
      fetch(`/api/deleteExam.php?exam_id=${examId}`, {
        method: 'DELETE',
      })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            setExams(exams.filter((exam) => exam.exam_id !== examId));
            setMessage('Exam removed successfully.');
            setMsgType('success');
            setTimeout(() => setMessage(''), 3000);
          } else {
            setMessage('Error deleting exam');
            setMsgType('danger');
          }
        })
        .catch(err => {
          console.error('Error deleting exam:', err);
          setMessage('Error deleting exam');
          setMsgType('danger');
        });
    }
  };

  if (loading) {
    return (
      <>
        <Header isLoggedIn={isAdminLoggedIn} isAdmin={true} onLogout={onLogout} />
        <div className="container mt-5">
          <div>Loading...</div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Header isLoggedIn={isAdminLoggedIn} isAdmin={true} onLogout={onLogout} />
      <div className="container">
        <div className="row">
          <div className="col-lg-12 text-center">
            <h1 className="mt-5">Exam List</h1>
            {message && <div className={`alert alert-${msgType}`}>{message}</div>}
            <br/>
          </div>

          <div className="col-lg-12">
            <table className="table table-striped table-bordered table-hover">
              <thead>
                <tr>
                  <th width="10%">#</th>
                  <th width="20%">Exam Name</th>
                  <th width="30%">Description</th>
                  <th width="15%">Date</th>
                  <th width="10%">Duration</th>
                  <th width="15%">ACTION</th>
                </tr>
              </thead>
              <tbody>
                {exams.length > 0 ? (
                  exams.map((exam, index) => (
                    <tr key={exam.exam_id}>
                      <td>{index + 1}</td>
                      <td>{exam.exam_name}</td>
                      <td>{exam.exam_desc}</td>
                      <td>{exam.exam_date}</td>
                      <td>{exam.duration_minutes} min</td>
                      <td>
                        <a
                          className="btn btn-danger"
                          onClick={(e) => {
                            e.preventDefault();
                            if (window.confirm('Are you sure to Delete this Exam?')) {
                              handleDelete(exam.exam_id);
                            }
                          }}
                          href="#"
                        >
                          Remove
                        </a>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="text-center">
                      No exams available.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default ExamList;
