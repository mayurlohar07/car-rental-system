import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Login = ({ setLogin, setUserName }) => {
  const [userName, setUserNameInput] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('userName', userName);
    formData.append('password', password);

    try {
      const response = await fetch('/api/loginUser.php', {
        method: 'POST',
        body: formData,
      });
      const data = await response.json();
      if (data.success) {
        setLogin(true);
        setUserName(data.user.name);
        localStorage.setItem("user_id", data.user.user_id);
        localStorage.setItem("username", data.user.userName);

        navigate('/exam');
      } else {
        document.querySelector('.error').style.display = 'block';
        document.querySelector('.error').textContent = data.message;
      }
    } catch (err) {
      document.querySelector('.error').style.display = 'block';
      document.querySelector('.error').textContent = 'An error occurred. Please try again.';
    }
  };

  return (
    <>
      <Header isLoggedIn={false} />
      <div className="container">
        <div className="row">
          <div className="col-lg-12 text-center">
            <h1 className="mt-5">Online Examination System</h1>
            <p className="lead">Simple MCQ Based Online Examination System!</p>
            <img src="/img/bgtest.png" width="130px;" alt="Test" />
          </div>

          <div className="col-lg-3"></div>

          <div className="col-lg-6">
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="userName">Username</label>
                <input
                  type="text"
                  className="form-control"
                  id="userName"
                  name="userName"
                  placeholder="Enter Username"
                  value={userName}
                  onChange={(e) => setUserNameInput(e.target.value)}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="password">Password</label>
                <input
                  type="password"
                  name="password"
                  id="password"
                  className="form-control"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              <button type="submit" id="loginsubm" className="btn btn-success">Log In</button>
            </form>
            <br />
            <p><a className="btn btn-outline-info btn-lg" href="/register">New User? Signup for Free</a></p>
            <span className="empty" style={{ display: 'none' }}>Fields must not be empty</span>
            <span className="disable" style={{ display: 'none' }}>User ID Disable!</span>
            <span className="error" style={{ display: 'none' }}>Email or Password did not match.</span>
          </div>

          <div className="col-lg-3"></div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Login;
