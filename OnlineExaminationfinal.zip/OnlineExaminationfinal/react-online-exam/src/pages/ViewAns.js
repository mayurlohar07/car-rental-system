import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';

const ViewAns = ({ isLoggedIn, userName, onLogout }) => {
  const [questions, setQuestions] = useState([]);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    // Fetch all questions and answers from PHP
    // Assuming /viewans.php returns JSON: { total: number, questions: [{ quesNo, ques, answers: [{ ans, rightAns }] }] }
    fetch('/viewans.php')
      .then(response => response.json())
      .then(data => {
        setTotal(data.total);
        setQuestions(data.questions);
      })
      .catch(err => console.error('Error fetching answers:', err));
  }, []);

  return (
    <>
      <Header isLoggedIn={isLoggedIn} userName={userName} onLogout={onLogout} />
      <div className="container">
        <div className="row">
          <div className="col-lg-12 text-center">
            <h1 className="mt-5">All Question & Answer - Total {total} Questions</h1>
            <br />
            <br />
          </div>

          <div className="col-lg-3"></div>

          <div className="col-lg-6">
            <table>
              {questions.map((question, index) => (
                <React.Fragment key={index}>
                  <tr>
                    <td colSpan="2">
                      <h5>Ques. {question.quesNo} : {question.ques}</h5>
                    </td>
                  </tr>
                  {question.answers.map((ans, ansIndex) => (
                    <tr key={ansIndex}>
                      <td>
                        <input type="radio" />
                        {ans.rightAns === '1' ? (
                          <span style={{ color: 'green', fontWeight: 'bold' }}>
                            {ans.ans} (Correct Ans)
                          </span>
                        ) : (
                          ans.ans
                        )}
                      </td>
                    </tr>
                  ))}
                </React.Fragment>
              ))}
            </table>

            <Link to="/exam" className="btn btn-success btn-lg">
              <span className="fa fa-arrow-right"></span> Start Exam
            </Link>
            <br />
            <br />
          </div>

          <div className="col-lg-3"></div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default ViewAns;
