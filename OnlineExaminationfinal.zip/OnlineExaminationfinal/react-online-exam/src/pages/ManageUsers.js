import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const ManageUsers = ({ isAdminLoggedIn, onLogout }) => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = () => {
    fetch('/api/getUsers.php')
      .then(response => response.json())
      .then(data => {
        setUsers(data);
      })
      .catch(err => {
        console.error('Error fetching users:', err);
      });
  };

  const handleDelete = (userId) => {
    if (window.confirm('Are you sure to Delete?')) {
      fetch(`/api/getUsers.php?del=${userId}`, {
        method: 'DELETE'
      })
        .then(response => response.json())
        .then(() => {
          setUsers(users.filter(user => user.userId !== userId));
        })
        .catch(err => console.error('Error deleting user:', err));
    }
  };

  return (
    <>
      <Header isLoggedIn={false} userName="" onLogout={onLogout} isAdmin={true} />
      <div className="container">
        <div className="row">
          <div className="col-lg-12 text-center">
            <h1 className="mt-5">Manage Users</h1>
            <br />
          </div>

          <div className="col-lg-12">
            <table className="table table-striped table-bordered table-hover">
              <thead>
                <tr>
                  <th>#</th>
                  <th>NAME</th>
                  <th>USERNAME</th>
                  <th>EMAIL</th>
                  <th>ACTION</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user, index) => (
                  <tr key={user.userId}>
                    <td>{user.status === '1' ? <span className="error">{index + 1}</span> : index + 1}</td>
                    <td>{user.name}</td>
                    <td>{user.userName}</td>
                    <td>{user.email}</td>
                    <td>
                      <button className="btn btn-danger" onClick={() => handleDelete(user.userId)}>
                        Remove
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default ManageUsers;
