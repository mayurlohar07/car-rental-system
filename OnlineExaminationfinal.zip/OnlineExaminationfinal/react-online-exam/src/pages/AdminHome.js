import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Link } from 'react-router-dom';

const AdminHome = ({ onLogout }) => {
  return (
    <>
      <Header isLoggedIn={true} isAdmin={true} onLogout={onLogout} />
      <div className="container">
        <div className="row">
          <div className="col-lg-12 text-center">
            <h1 className="mt-5">Welcome to Exam Control Panel - Admin</h1>
            <br />
            <br />
            <div className="jumbotron">
              <h1>Controls</h1>
              <Link className="btn btn-outline-success btn-lg" to="/adminhome">
          <span className="fa fa-home" style={{ color: "#28a745" }}></span> Home
        </Link>

        <Link className="btn btn-outline-info btn-lg" to="/manageusers">
          <span className="fa fa-user-circle" style={{ color: "#17a2b8" }}></span> Manage Users
        </Link>

        <Link className="btn btn-outline-primary btn-lg" to="/addquestion">
          <span className="fa fa-question-circle" style={{ color: "#007bff" }}></span> Add Question
        </Link>

        <Link className="btn btn-outline-warning btn-lg" to="/managequestions">
          <span className="fa fa-list" style={{ color: "#ffc107" }}></span> Manage Question
        </Link>
        <Link className="btn btn-outline-danger btn-lg" to="/admin" onClick={onLogout}>
          <span className="fa fa-sign-out" style={{ color: "#dc3545" }}></span> Logout
              </Link>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default AdminHome;
