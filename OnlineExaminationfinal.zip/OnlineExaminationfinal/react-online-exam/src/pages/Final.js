import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Final = ({ isLoggedIn, userName, onLogout }) => {
  const [score, setScore] = useState(null);

  useEffect(() => {
    // Fetch the final score from PHP
    fetch('/final.php')
      .then(response => response.text())
      .then(data => {
        // Parse the score from the HTML response
        const scoreMatch = data.match(/Final Score:\s*(\d+)/);
        if (scoreMatch) {
          setScore(scoreMatch[1]);
        }
      })
      .catch(err => console.error('Error fetching score:', err));
  }, []);

  return (
    <>
      <Header isLoggedIn={isLoggedIn} userName={userName} onLogout={onLogout} />
      <div className="container">
        <div className="row">
          <div className="col-lg-12 text-center">
            <h1 className="mt-5">Congratulations! You have just completed test.</h1>
            <p className="lead">Check your final score. You can also check the correct answers.</p>
            <br />

            <div className="jumbotron">
              <h1 className="text-danger">
                Final Score: {score !== null ? score : 'Loading...'}
              </h1>
            </div>
            <br />
            <br />
            <Link to="/viewans" className="btn btn-outline-success btn-lg">
              <span className="fa fa-check-circle"></span> View Answer
            </Link>
            <Link to="/exam" className="btn btn-outline-info btn-lg">
              <span className="fa fa-arrow-right"></span> Start Test Again
            </Link>
            <br />
            <br />
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Final;
