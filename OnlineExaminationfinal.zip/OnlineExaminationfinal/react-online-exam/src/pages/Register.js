import React, { useState } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Register = () => {
  const [name, setName] = useState('');
  const [userName, setUserName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('name', name);
    formData.append('userName', userName);
    formData.append('email', email);
    formData.append('password', password);

    try {
      const response = await fetch('/api/registerUser.php', {
        method: 'POST',
        body: formData,
      });
      const data = await response.json();
      if (data.success) {
        alert('Registration Successful. Please login.');
        // Clear form on success
        setName('');
        setUserName('');
        setEmail('');
        setPassword('');
        setMessage('');
      } else {
        setMessage(data.message);
      }
    } catch (err) {
      setMessage('An error occurred. Please try again.');
    }
  };

  return (
    <>
      <Header isLoggedIn={false} />
      <div className="container">
        <div className="row">
          <div className="col-lg-12 text-center">
            <h1 className="mt-5">Online Examination System</h1>
            <p className="lead">Complete MCQ Based Online Examination System!</p>
            <img src="/img/regi.png" width="130px;" alt="Register" />
          </div>

          <div className="col-lg-2"></div>

          <div className="col-lg-8">
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="name">FullName</label>
                <input
                  type="text"
                  className="form-control"
                  id="name"
                  name="name"
                  placeholder="Enter Your FullName"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
                <small className="form-text text-muted">Enter your full name (Spaces allowed).</small>
              </div>

              <div className="form-group">
                <label htmlFor="userName">Username</label>
                <input
                  type="text"
                  className="form-control"
                  id="userName"
                  name="userName"
                  placeholder="Enter Username (without spaces)"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  required
                />
                <small className="form-text text-muted">Enter only the username</small>
              </div>

              <div className="form-group">
                <label htmlFor="email">Email Address</label>
                <input
                  type="email"
                  className="form-control"
                  id="email"
                  name="email"
                  placeholder="Enter Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
                <small className="form-text text-muted">We'll never share your email with anyone else.</small>
              </div>
              <div className="form-group">
                <label htmlFor="password">Password</label>
                <input
                  type="password"
                  name="password"
                  id="password"
                  className="form-control"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              <button type="submit" id="registersubm" className="btn btn-success">Register</button>
              <a className="btn btn-outline-danger" href="/">Already Registered? Login</a>
            </form>
            <br />
            <br />
            <span id="state">{message}</span>
          </div>

          <div className="col-lg-2"></div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Register;
