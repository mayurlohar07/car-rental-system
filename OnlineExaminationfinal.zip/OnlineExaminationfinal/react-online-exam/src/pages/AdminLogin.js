import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';

const AdminLogin = ({ setAdminLogin }) => {
  const [adminUser, setAdminUser] = useState('');
  const [adminPass, setAdminPass] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const dataString = `adminUser=${encodeURIComponent(adminUser)}&adminPass=${encodeURIComponent(adminPass)}`;
    try {
      const response = await fetch('/admin/login.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: dataString,
      });
      const text = await response.text();
      const trimmed = text.trim();
      if (trimmed.includes('error') || trimmed.includes('Invalid')) {
        setError('Username or Password did not match.');
      } else {
        setAdminLogin(true);
        navigate('/adminhome');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
    }
  };

  return (
    <>
      <Header isLoggedIn={false} isAdmin={true} />
      <div className="container">
        <div className="row">
          <div className="col-lg-12 text-center">
            <h1 className="mt-5">Login - Administration Panel</h1>
            <br />
          </div>

          <div className="col-lg-3"></div>

          <div className="col-lg-6">
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="adminUser">Username</label>
                <input
                  type="text"
                  className="form-control"
                  id="adminUser"
                  name="adminUser"
                  placeholder="Enter Username"
                  value={adminUser}
                  onChange={(e) => setAdminUser(e.target.value)}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="adminPass">Password</label>
                <input
                  type="password"
                  className="form-control"
                  id="adminPass"
                  name="adminPass"
                  placeholder="Enter Password"
                  value={adminPass}
                  onChange={(e) => setAdminPass(e.target.value)}
                  required
                />
              </div>
              <button type="submit" className="btn btn-danger">Log In</button>
            </form>
            {error && <div className="text-danger mt-2">{error}</div>}
          </div>

          <div className="col-lg-3"></div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default AdminLogin;
