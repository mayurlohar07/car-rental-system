import React, { useEffect, useState } from "react";

const ExamList = () => {
  const [exams, setExams] = useState([]);
  const [message, setMessage] = useState("");

  // Fetch exam list from backend
  const fetchExams = () => {
    fetch("http://localhost/OnlineExamination-PHP/api/getAllExams.php")
      .then((res) => res.json())
      .then((data) => setExams(data))
      .catch(() => setMessage("Unable to load exams"));
  };

  // Load exams on page load
  useEffect(() => {
    fetchExams();
  }, []);

  // Delete exam
  const deleteExam = (exam_id) => {
    if (!window.confirm("Are you sure to Delete this Exam?")) return;

    fetch(`http://localhost/OnlineExamination-PHP/api/deleteExam.php?exam_id=${exam_id}`)
      .then((res) => res.json())
      .then((data) => {
        setMessage(data.message);
        fetchExams(); // reload list
      })
      .catch(() => setMessage("Unable to delete exam"));
  };

  return (
    <div className="container">
      <div className="row">

        <div className="col-lg-12 text-center">
          {message && <p>{message}</p>}
          <h1 className="mt-5">Exam List</h1>
          <br />
        </div>

        <div className="col-lg-12">
          <table className="table table-striped table-bordered table-hover">
            <thead>
              <tr>
                <th width="10%">#</th>
                <th width="20%">Exam Name</th>
                <th width="30%">Description</th>
                <th width="15%">Date</th>
                <th width="10%">Duration</th>
                <th width="15%">ACTION</th>
              </tr>
            </thead>

            <tbody>
              {exams.length > 0 ? (
                exams.map((exam, index) => (
                  <tr key={exam.exam_id}>
                    <td>{index + 1}</td>
                    <td>{exam.exam_name}</td>
                    <td>{exam.exam_desc}</td>
                    <td>{exam.exam_date}</td>
                    <td>{exam.duration_minutes} min</td>
                    <td>
                      <button
                        className="btn btn-danger"
                        onClick={() => deleteExam(exam.exam_id)}
                      >
                        Remove
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="text-center">
                    No exams found
                  </td>
                </tr>
              )}
            </tbody>

          </table>
        </div>

      </div>
    </div>
  );
};

export default ExamList;
