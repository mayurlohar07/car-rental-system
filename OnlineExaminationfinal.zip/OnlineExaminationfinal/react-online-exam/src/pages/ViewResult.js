import React, { useEffect, useState } from "react";

const ViewResult = () => {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("http://localhost/OnlineExamination-PHP/api/ViewResult.php")
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          setResults(data.results);
        }
        setLoading(false);
      })
      .catch(err => {
        console.error("Error loading results:", err);
        setLoading(false);
      });
  }, []);

  if (loading) return <div className="text-center mt-5">Loading...</div>;

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">All Results !</h2>

      {results.length === 0 ? (
        <h4 className="text-center">No records found.</h4>
      ) : (
        <table className="table table-bordered table-striped">
          <thead className="table-dark">
            <tr>
              <th>User ID</th>
              <th>Exam ID</th>
              <th>Score</th>
              <th>Username</th>
            </tr>
          </thead>
          <tbody>
            {results.map((r, i) => (
              <tr key={i}>
                <td>{r.user_id}</td>
                <td>{r.exam_id}</td>
                <td>{r.score}</td>
                <td>{r.username}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default ViewResult;
