import React, { useEffect, useState } from "react";
import { useParams, useLocation, useNavigate } from "react-router-dom";

const StartExam = () => {
  const { exam_id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();

  const user_id = location.state?.user_id;
  const username = location.state?.username;
  const [questions, setQuestions] = useState([]);
  const [current, setCurrent] = useState(0);
  const [selectedAns, setSelectedAns] = useState(null);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);

  useEffect(() => {

    // Load the exam questions
    fetch(`http://localhost/OnlineExamination-PHP/api/getQuestions.php?exam_id=${exam_id}`)
      .then(res => res.json())
      .then(data => setQuestions(data))
      .catch(() => alert("Unable to load exam questions"));
  }, [exam_id, user_id, navigate]);

  if (!questions.length) {
    return <div className="container mt-5 text-center">Loading questions...</div>;
  }

  const currentQuestion = questions[current];

  const handleNext = () => {
    if (selectedAns === null) {
      alert("Please select an answer!");
      return;
    }

    if (selectedAns == currentQuestion.answer) {
      setScore(score + 1);
    }

    if (current + 1 < questions.length) {
      setCurrent(current + 1);
      setSelectedAns(null);
    } else {
      submitScore(score + (selectedAns == currentQuestion.answer ? 1 : 0));
    }
  };

  const submitScore = (finalScore) => {
  fetch("http://localhost/OnlineExamination-PHP/api/saveScore.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      user_id,
      exam_id,
      score: finalScore
    })
  })
    .then(res => res.json())
    .then(data => {
      console.log("Save Score Response:", data); // <--- ADD THIS

      if (data.success) {
        setFinished(true);
      } else {
        alert("Error: " + data.error);
      }
    })
    .catch((error) => {
      console.error("Save Score Fetch Error:", error);
      alert("Failed to save score (Network error)");
      console.log("Final Score to be submitted:", finalScore);
      console.log("User ID:", user_id);
      console.log("Exam ID:", exam_id); 
      console.log("Username:", username);
    });
};


  if (finished) {
    return (
      <div className="container mt-5 text-center">
        <h2>Exam Finished!</h2>
        <h3>Your Score: {score} / {questions.length}</h3>
      </div>
    );
  }

  return (
    <div className="container mt-5">
      <h4>Question {current + 1} of {questions.length}</h4>
      <h5 className="mt-3">{currentQuestion.question}</h5>

      <div className="mt-4">
        {[currentQuestion.option1, currentQuestion.option2, currentQuestion.option3, currentQuestion.option4]
          .map((option, index) => (
            <div key={index} className="form-check mb-2">
              <input
                className="form-check-input"
                type="radio"
                name="answer"
                checked={selectedAns === index + 1}
                onChange={() => setSelectedAns(index + 1)}
              />
              <label className="form-check-label">{option}</label>
            </div>
        ))}
      </div>

      <button className="btn btn-success mt-3" onClick={handleNext}>
        {current + 1 === questions.length ? "Finish Exam" : "Next"}
      </button>
    </div>
  );
};

export default StartExam;
