import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Exam = ({ isLoggedIn, userName, onLogout }) => {
  const navigate = useNavigate();
  const [exams, setExams] = useState([]);
  const [error, setError] = useState('');
  const user_id = localStorage.getItem("user_id");
const username = localStorage.getItem("username");



  useEffect(() => {
    if (!isLoggedIn) {
      navigate('/');
      return;
    }

    // Fetch all exams from backend
    fetch("http://localhost/OnlineExamination-PHP/api/getAllExams.php")
      .then(response => {
        if (!response.ok) throw new Error("Failed to load exams");
        return response.json();
      })
      .then(data => {
        setExams(data);
        setError('');
      })
      .catch(err => {
        setError(err.message);
      });
  }, [isLoggedIn, navigate]);

  const handleStartExam = (exam_id) => {
  navigate(`/start-exam/${exam_id}`, {
    state: { user_id: user_id, username: username }
  });
};


  if (error) return <div>Error: {error}</div>;

  return (
    <>
      <Header isLoggedIn={isLoggedIn} userName={userName} onLogout={onLogout} />

      <div className="container mt-5">
        <div className="row">

          <div className="col-lg-12 text-center">
            <h1 className="mt-4">Available Exams</h1>
            <br />
          </div>

          {exams.length > 0 ? (
            exams.map((exam) => (
              <div className="col-lg-4 mb-4" key={exam.exam_id}>
                <div className="card shadow-sm p-3">
                  <h4>{exam.exam_name}</h4>
                  <p>{exam.exam_desc}</p>
                  <p><b>Date:</b> {exam.exam_date}</p>
                  <p><b>Duration:</b> {exam.duration_minutes} minutes</p>
                  <button
                    className="btn btn-primary"
                    onClick={() => handleStartExam(exam.exam_id)}
                  >
                    Start Exam
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div className="col-lg-12 text-center">
              <p>No exams available.</p>
            </div>
          )}

        </div>
      </div>

      <Footer />
    </>
  );
};

export default Exam;
