import React, { useState } from "react";

const AddExam = () => {
  const [formData, setFormData] = useState({
    examName: "",
    examDesc: "",
    examDate: "",
    examDuration: "",
    totalQuestions: "",
  });

  const [message, setMessage] = useState("");

  // Handle input change
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Submit form (SAME STRUCTURE AS AddQuestion.js)
  const handleSubmit = async (e) => {
    e.preventDefault();

    const examData = {
      examName: formData.examName,
      examDesc: formData.examDesc,
      examDate: formData.examDate,
      examDuration: parseInt(formData.examDuration),
      totalQuestions: parseInt(formData.totalQuestions),
    };

    try {
      const response = await fetch("http://localhost/OnlineExamination-PHP/api/addexam.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",  // IMPORTANT!
        },
        body: JSON.stringify(examData),         // Send JSON data
      });

      const data = await response.json();

      if (data.success) {
        setMessage("Exam Added Successfully!");

        // Reset form
        setFormData({
          examName: "",
          examDesc: "",
          examDate: "",
          examDuration: "",
          totalQuestions: "",
        });
      } else {
        setMessage(data.message || "Failed to add exam.");
      }

    } catch (error) {
      setMessage("Error: Unable to add exam");
    }
  };

  return (
    <div className="container">
      <div className="row">

        <div className="col-lg-12 text-center">
          <h1 className="mt-5">Add Exam</h1>
          {message && <p>{message}</p>}
          <br />
        </div>

        <div className="col-lg-3"></div>

        <div className="col-lg-6">
          <form onSubmit={handleSubmit}>
            <table className="table-borderless" style={{ width: "100%" }}>
              <tbody>
                <tr>
                  <td>Exam Name</td>
                  <td> : </td>
                  <td>
                    <input
                      className="form-control"
                      type="text"
                      name="examName"
                      value={formData.examName}
                      onChange={handleChange}
                      placeholder="Enter Exam Name"
                      required
                    />
                  </td>
                </tr>

                <tr>
                  <td>Description</td>
                  <td> : </td>
                  <td>
                    <textarea
                      className="form-control"
                      name="examDesc"
                      value={formData.examDesc}
                      onChange={handleChange}
                      placeholder="Enter Exam Description"
                      rows="4"
                      required
                    />
                  </td>
                </tr>

                <tr>
                  <td>Exam Date</td>
                  <td> : </td>
                  <td>
                    <input
                      className="form-control"
                      type="date"
                      name="examDate"
                      value={formData.examDate}
                      onChange={handleChange}
                      required
                    />
                  </td>
                </tr>

                <tr>
                  <td>Duration (minutes)</td>
                  <td> : </td>
                  <td>
                    <input
                      className="form-control"
                      type="number"
                      name="examDuration"
                      value={formData.examDuration}
                      onChange={handleChange}
                      placeholder="Enter Duration"
                      required
                    />
                  </td>
                </tr>

                <tr>
                  <td>Total Questions</td>
                  <td> : </td>
                  <td>
                    <input
                      className="form-control"
                      type="number"
                      name="totalQuestions"
                      value={formData.totalQuestions}
                      onChange={handleChange}
                      placeholder="Enter Total Questions"
                      required
                    />
                  </td>
                </tr>

                <tr>
                  <td colSpan="3" align="center">
                    <input type="submit" className="btn btn-success" value="Add Exam" />
                  </td>
                </tr>
              </tbody>
            </table>
          </form>
        </div>

        <div className="col-lg-3"></div>

      </div>
    </div>
  );
};

export default AddExam;
