import React, { useState } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Profile = ({ isLoggedIn, userName, onLogout }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('name', name);
    formData.append('email', email);
    formData.append('update', 'Update');

    try {
      const response = await fetch('/profile.php', {
        method: 'POST',
        body: formData,
      });
      const data = await response.text();
      setMessage(data);
    } catch (err) {
      setMessage('An error occurred.');
    } 
  };

  return (
    <>
      <Header isLoggedIn={isLoggedIn} userName={userName} onLogout={onLogout} />
      <div className="container">
        <div className="row">
          <div className="col-lg-12 text-center">
            <h1 className="mt-5">Update Your Profile</h1>
            <br />
          </div>

          <div className="col-lg-3"></div>

          <div className="col-lg-6">
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="name">Full Name</label>
                <input
                  type="text"
                  className="form-control"
                  name="name"
                  placeholder="Enter Full Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="email">Email Address</label>
                <input
                  type="email"
                  className="form-control"
                  name="email"
                  placeholder="Enter Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <button type="submit" name="update" value="Update" className="btn btn-success">Update</button>
            </form>
            <br />
            {message && <div>{message}</div>}
          </div>

          <div className="col-lg-3"></div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Profile;
