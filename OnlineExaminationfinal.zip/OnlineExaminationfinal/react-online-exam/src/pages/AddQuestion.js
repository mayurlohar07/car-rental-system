import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const AddQuestion = ({ isAdminLoggedIn, onLogout }) => {

  const [examList, setExamList] = useState([]);
  const [selectedExam, setSelectedExam] = useState("");
  const [quesNo, setQuesNo] = useState(1);
  const [ques, setQues] = useState('');
  const [ans1, setAns1] = useState('');
  const [ans2, setAns2] = useState('');
  const [ans3, setAns3] = useState('');
  const [ans4, setAns4] = useState('');
  const [rightAns, setRightAns] = useState(1);
  const [message, setMessage] = useState('');

  // Load Exams Dropdown
  useEffect(() => {
    fetch("api/getAllExams.php")
      .then(res => res.json())
      .then(data => setExamList(data))
      .catch(err => console.log("Error fetching exams", err));
  }, []);

  // Load next question number for selected exam
  useEffect(() => {
    if (!selectedExam) return;

    fetch(`api/getLastQuestionNumber.php?exam_id=${selectedExam}`)
      .then(res => res.json())
      .then(data => setQuesNo(data.nextQuesNo))
      .catch(err => console.log("Error loading next ques number"));
  }, [selectedExam]);


  const handleSubmit = (e) => {
    e.preventDefault();

    if (!selectedExam) {
      setMessage("Please select an exam first!");
      return;
    }

    const questionData = {
      exam_id: selectedExam,
      que_number: quesNo,
      question: ques,
      option1: ans1,
      option2: ans2,
      option3: ans3,
      option4: ans4,
      answer: parseInt(rightAns)
    };

    fetch("api/addQuestion.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(questionData),
    })
      .then((response) => response.json())
      .then((data) => {
        setMessage(data.message);

        if (data.success) {
          setQues('');
          setAns1('');
          setAns2('');
          setAns3('');
          setAns4('');
          setRightAns(1);

          // update next question number
          setQuesNo(quesNo + 1);
        }
      })
      .catch(() => setMessage("Error adding question"));
  };

  return (
    <>
      <Header isLoggedIn={false} userName="" onLogout={onLogout} isAdmin={true} />
      <div className="container">
        <div className="row">

          <div className="col-lg-12 text-center">
            <h1 className="mt-5">Add Questions</h1>
            {message && <div>{message}</div>}
            <br />
          </div>

          <div className="col-lg-3"></div>

          <div className="col-lg-6">
            <form onSubmit={handleSubmit}>

              <table className="">
                <tbody>

                  {/* Select Exam */}
                  <tr>
                    <td>Select Exam</td>
                    <td> : </td>
                    <td width="80%">
                      <select
                        className="form-control"
                        value={selectedExam}
                        onChange={(e) => setSelectedExam(e.target.value)}
                        required
                      >
                        <option value="">-- Select Exam --</option>
                        {examList.map((exam) => (
                          <option key={exam.exam_id} value={exam.exam_id}>
                            {exam.exam_name}
                          </option>
                        ))}
                      </select>
                    </td>
                  </tr>

                  <tr>
                    <td>Question No</td>
                    <td> : </td>
                    <td>
                      <input className="form-control" readOnly value={quesNo} />
                    </td>
                  </tr>

                  <tr>
                    <td>Question</td>
                    <td> : </td>
                    <td>
                      <input
                        className="form-control"
                        type="text"
                        value={ques}
                        onChange={(e) => setQues(e.target.value)}
                        required
                      />
                    </td>
                  </tr>

                  <tr><td>Choice 1</td><td> : </td>
                    <td><input className="form-control" value={ans1} onChange={(e) => setAns1(e.target.value)} /></td>
                  </tr>

                  <tr><td>Choice 2</td><td> : </td>
                    <td><input className="form-control" value={ans2} onChange={(e) => setAns2(e.target.value)} /></td>
                  </tr>

                  <tr><td>Choice 3</td><td> : </td>
                    <td><input className="form-control" value={ans3} onChange={(e) => setAns3(e.target.value)} /></td>
                  </tr>

                  <tr><td>Choice 4</td><td> : </td>
                    <td><input className="form-control" value={ans4} onChange={(e) => setAns4(e.target.value)} /></td>
                  </tr>

                  <tr>
                    <td>Correct Answer No</td>
                    <td> : </td>
                    <td>
                      <input
                        className="form-control"
                        type="number"
                        min="1"
                        max="4"
                        value={rightAns}
                        onChange={(e) => setRightAns(e.target.value)}
                      />
                    </td>
                  </tr>

                  <tr>
                    <td colSpan="3" align="center">
                      <input type="submit" className="btn btn-success" value="Submit Question" />
                    </td>
                  </tr>

                </tbody>
              </table>

            </form>
          </div>

          <div className="col-lg-3"></div>

        </div>
      </div>

      <Footer />
    </>
  );
};

export default AddQuestion;
