<?php

// Script to add existing questions to "PHP Exam"

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "mcqexamination";

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert "PHP Exam" into tbl_exam
$exam_title = "PHP Exam";
$exam_description = "Exam on PHP basics";
$exam_date = date('Y-m-d'); // Today's date
$exam_duration = 60; // 60 minutes
$total_questions = 3; // Assuming 3 sample questions

$sql = "INSERT INTO tbl_exam (exam_title, exam_description, exam_date, exam_duration, total_questions) VALUES ('$exam_title', '$exam_description', '$exam_date', '$exam_duration', '$total_questions')";

if ($conn->query($sql) === TRUE) {
    $exam_id = $conn->insert_id;
    echo "Exam 'PHP Exam' inserted with ID: $exam_id\n";

    // Update existing questions to associate with this exam
    $update_sql = "UPDATE tbl_ques SET exam_id = $exam_id WHERE exam_id IS NULL";
    if ($conn->query($update_sql) === TRUE) {
        echo "Existing questions associated with 'PHP Exam'\n";
    } else {
        echo "Error updating questions: " . $conn->error . "\n";
    }
} else {
    echo "Error inserting exam: " . $conn->error . "\n";
}

$conn->close();
echo "Update completed.\n";
?>
