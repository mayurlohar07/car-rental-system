<?php include 'inc/header.php'; ?>
<?php
Session::checkSession();

$user_id = Session::get("userId");
$allExams = $exam->getAllExams();
?>

<style>
body{
    background:#f4f6f9;
}
.exam-box{
    background:#ffffff;
    padding:40px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    margin-top:50px;
    margin-bottom:50px;
}
.page-title{
    background:linear-gradient(135deg,#007bff,#6610f2);
    color:#fff;
    padding:30px;
    border-radius:12px;
    margin-bottom:30px;
}
.page-title h1{
    margin:0;
    font-size:34px;
    font-weight:700;
}
.page-title p{
    margin-top:10px;
    font-size:17px;
    opacity:.95;
}
.exam-card{
    border:1px solid #e5e5e5;
    border-radius:12px;
    padding:22px;
    margin-bottom:20px;
    text-align:left;
    transition:.3s;
    display:block;
    color:#333;
    background:#fff;
}
.exam-card:hover{
    transform:translateY(-4px);
    box-shadow:0 10px 20px rgba(0,0,0,0.08);
}
.exam-card h5{
    font-size:22px;
    font-weight:700;
    color:#007bff;
}
.exam-card p{
    margin-bottom:10px;
    color:#555;
}
.exam-meta{
    font-size:14px;
    color:#666;
    margin-bottom:15px;
}
.btn-pay{
    background:#dc3545;
    color:#fff;
    padding:10px 22px;
    border-radius:8px;
    text-decoration:none;
    font-weight:600;
}
.btn-pay:hover{
    background:#bb2d3b;
    color:#fff;
}
.btn-start{
    background:#198754;
    color:#fff;
    padding:10px 22px;
    border-radius:8px;
    text-decoration:none;
    font-weight:600;
}
.btn-start:hover{
    background:#157347;
    color:#fff;
}
.no-exam{
    font-size:18px;
    color:#dc3545;
    font-weight:600;
}
</style>

<div class="container">

    <div class="row justify-content-center">

        <div class="col-lg-10">

            <div class="exam-box text-center">

                <div class="page-title">
                    <h1>Welcome to Online Examination</h1>
                    <p>Select an Exam & Complete Payment to Start</p>
                </div>

                <?php if ($allExams) { ?>

                    <?php while ($examData = $allExams->fetch_assoc()) { ?>

                        <?php
                        $exam_id = $examData['exam_id'];

                        $payCheck = $db->select("
                            SELECT id FROM tbl_payments 
                            WHERE user_id='$user_id' 
                            AND exam_id='$exam_id'
                            AND payment_status='paid'
                            LIMIT 1
                        ");
                        ?>

                        <div class="exam-card">

                            <h5><?php echo $examData['exam_name']; ?></h5>

                            <p><?php echo $examData['exam_desc']; ?></p>

                            <div class="exam-meta">
                                Date: <?php echo $examData['exam_date']; ?>
                                |
                                Duration: <?php echo $examData['duration_minutes']; ?> Minutes
                                |
                                Questions: <?php echo $examData['total_questions']; ?>
                                |
                                Fees: ₹<?php echo $examData['exam_fee']; ?>
                            </div>

                           <?php if ($payCheck && $payCheck->num_rows > 0) { ?>

                                <a href="test.php?exam_id=<?php echo $exam_id; ?>" class="btn-start">
                                    Start Exam
                                </a>

                            <?php } else { ?>

                                <a href="payment.php?exam_id=<?php echo $exam_id; ?>" class="btn-pay">
                                    Pay ₹<?php echo $examData['exam_fee']; ?>
                                </a>

                            <?php } ?>

                        </div>

                    <?php } ?>

                <?php } else { ?>

                    <p class="no-exam">No exams available at the moment.</p>

                <?php } ?>

            </div>

        </div>

    </div>

</div>

<?php include 'inc/footer.php'; ?>