<?php include 'inc/header.php'; ?>
<?php
Session::checkSession();
$userId = Session::get("userId");
?>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userProfile = $user->getUserPData($userId, $_POST);
}
?>

<style>
body{
    background:#f4f6f9;
}
.profile-box{
    background:#ffffff;
    padding:40px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    margin-top:50px;
    margin-bottom:50px;
}
.page-title{
    background:linear-gradient(135deg,#007bff,#6610f2);
    color:#fff;
    padding:28px;
    border-radius:12px;
    text-align:center;
    margin-bottom:30px;
}
.page-title h1{
    margin:0;
    font-size:34px;
    font-weight:700;
}
.table td{
    padding:12px;
    vertical-align:middle;
}
.btn-update{
    padding:12px 28px;
    font-size:18px;
    border-radius:10px;
    width:100%;
}
</style>

<div class="container">

    <div class="row justify-content-center">

        <div class="col-lg-6">

            <div class="profile-box">

                <div class="page-title">
                    <h1>Update Your Profile</h1>
                </div>

                <?php
                if (isset($userProfile)) {
                    echo $userProfile;
                }
                ?>

                <form action="" method="post">

                    <?php
                    $getData = $user->getUserProfile($userId);

                    if ($getData) {
                        while ($result = $getData->fetch_assoc()) {
                    ?>

                    <table class="table table-borderless">

                        <tr>
                            <td width="30%"><strong>Name</strong></td>
                            <td>
                                <input type="text"
                                       class="form-control"
                                       name="name"
                                       value="<?php echo $result['name']; ?>"
                                       id="name">
                            </td>
                        </tr>

                        <tr>
                            <td><strong>User Name</strong></td>
                            <td>
                                <input type="text"
                                       class="form-control"
                                       name="userName"
                                       value="<?php echo $result['userName']; ?>"
                                       id="userName">
                            </td>
                        </tr>

                        <tr>
                            <td><strong>Email</strong></td>
                            <td>
                                <input type="email"
                                       class="form-control"
                                       name="email"
                                       value="<?php echo $result['email']; ?>"
                                       id="email">
                            </td>
                        </tr>

                        <tr>
                            <td></td>
                            <td>
                                <input type="submit"
                                       id="profileUpdate"
                                       class="btn btn-info btn-update"
                                       value="Update Info">
                            </td>
                        </tr>

                    </table>

                    <?php } } ?>

                </form>

            </div>

        </div>

    </div>

</div>

<?php include 'inc/footer.php'; ?>