<?php include 'inc/header.php'; ?>
<?php
Session::checkSession();

$user_id   = Session::get("userId");
$username  = Session::get("name");

// ----------------------------
// GET EXAM ID
// ----------------------------
if (!isset($_GET['exam_id'])) {
    header("Location:starttest.php");
    exit();
}

$exam_id = (int)$_GET['exam_id'];

// ----------------------------
// GET EXAM DETAILS
// ----------------------------
$query = "SELECT * FROM tbl_exam WHERE exam_id='$exam_id' LIMIT 1";
$getExam = $db->select($query);

if (!$getExam) {
    header("Location:starttest.php");
    exit();
}

$examData = $getExam->fetch_assoc();

$exam_name  = $examData['exam_name'];
$exam_fees  = $examData['exam_fee'];

// ----------------------------
// ALREADY PAID CHECK
// ----------------------------
$paidCheck = $db->select("
    SELECT id FROM tbl_payments
    WHERE user_id='$user_id'
    AND exam_id='$exam_id'
    AND payment_status='paid'
    LIMIT 1
");

if ($paidCheck) {
    header("Location:test.php?exam_id=".$exam_id);
    exit();
}

// ----------------------------
// PAYMENT SUCCESS INSERT
// ----------------------------
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $payment_id = $_POST['payment_id'];

    $insert = "
        INSERT INTO tbl_payments(
            user_id,
            exam_id,
            amount,
            payment_id,
            payment_status,
            created_at
        ) VALUES(
            '$user_id',
            '$exam_id',
            '$exam_fees',
            '$payment_id',
            'paid',
            NOW()
        )
    ";

    $db->insert($insert);

    header("Location:test.php?exam_id=".$exam_id);
    exit();
}
?>

<style>
body{
    background:#f4f6f9;
}
.pay-box{
    background:#ffffff;
    padding:45px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    margin-top:60px;
    margin-bottom:60px;
}
.pay-title{
    background:linear-gradient(135deg,#007bff,#6610f2);
    color:#fff;
    padding:28px;
    border-radius:12px;
    margin-bottom:30px;
}
.pay-title h1{
    margin:0;
    font-size:32px;
    font-weight:700;
}
.exam-name{
    font-size:28px;
    font-weight:700;
    color:#007bff;
}
.amount{
    font-size:42px;
    font-weight:800;
    color:#198754;
}
.btn-pay{
    background:#198754;
    color:#fff;
    border:none;
    padding:14px 35px;
    font-size:20px;
    border-radius:10px;
}
.btn-pay:hover{
    background:#157347;
}
</style>

<div class="container">

    <div class="row justify-content-center">

        <div class="col-lg-7">

            <div class="pay-box text-center">

                <div class="pay-title">
                    <h1>Complete Payment</h1>
                </div>

                <p class="mb-2">Hello <strong><?php echo $username; ?></strong></p>

                <div class="exam-name mb-3">
                    <?php echo $exam_name; ?>
                </div>

                <p>Exam Access Fee</p>

                <div class="amount mb-4">
                    ₹<?php echo $exam_fees; ?>
                </div>

                <button id="rzp-button1" class="btn btn-pay">
                    Pay Now
                </button>

                <p class="mt-4 text-muted">
                    Secure payment powered by Razorpay
                </p>

            </div>

        </div>

    </div>

</div>

<form method="post" id="successForm">
    <input type="hidden" name="payment_id" id="payment_id">
</form>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>

<script>
var options = {
    "key": "<?php echo RAZORPAY_KEY_ID; ?>",
    "amount": "<?php echo $exam_fees * 100; ?>",
    "currency": "INR",
    "name": "Online Examination",
    "description": "<?php echo $exam_name; ?>",
    "image": "",
    "handler": function (response){

        document.getElementById("payment_id").value =
            response.razorpay_payment_id;

        document.getElementById("successForm").submit();
    },

    "theme": {
        "color": "#198754"
    }
};

var rzp1 = new Razorpay(options);

document.getElementById('rzp-button1').onclick = function(e){
    rzp1.open();
    e.preventDefault();
}
</script>

<?php include 'inc/footer.php'; ?>