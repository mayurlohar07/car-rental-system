<?php

// Database setup script for OnlineExamination-PHP

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "mcqexamination";

// Create connection without database
$conn = new mysqli($host, $user, $pass);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database
$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully\n";
} else {
    echo "Error creating database: " . $conn->error . "\n";
}

// Select database
$conn->select_db($dbname);

// Create tbl_ques table
$sql = "CREATE TABLE IF NOT EXISTS tbl_ques (
    quesNo INT(11) NOT NULL AUTO_INCREMENT,
    ques TEXT NOT NULL,
    exam_id INT(11) NOT NULL,
    PRIMARY KEY (quesNo),
    FOREIGN KEY (exam_id) REFERENCES tbl_exam(exam_id)
)";

if ($conn->query($sql) === TRUE) {
    echo "Table tbl_ques created successfully\n";
} else {
    echo "Error creating table tbl_ques: " . $conn->error . "\n";
}

// Create tbl_ans table
$sql = "CREATE TABLE IF NOT EXISTS tbl_ans (
    id INT(11) NOT NULL AUTO_INCREMENT,
    quesNo INT(11) NOT NULL,
    rightAns INT(1) NOT NULL,
    ans TEXT NOT NULL,
    PRIMARY KEY (id)
)";

if ($conn->query($sql) === TRUE) {
    echo "Table tbl_ans created successfully\n";
} else {
    echo "Error creating table tbl_ans: " . $conn->error . "\n";
}

// Create tbl_exam table
$sql = "CREATE TABLE IF NOT EXISTS tbl_exam (
    exam_id INT(11) NOT NULL AUTO_INCREMENT,
    exam_title VARCHAR(255) NOT NULL,
    exam_description TEXT,
    exam_date DATE NOT NULL,
    exam_duration INT(11) NOT NULL COMMENT 'in minutes',
    total_questions INT(11) NOT NULL,
    status ENUM('Active','Inactive') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (exam_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($conn->query($sql) === TRUE) {
    echo "Table tbl_exam created successfully\n";
} else {
    echo "Error creating table tbl_exam: " . $conn->error . "\n";
}

// Insert sample exams
$exams = [
    [
        'exam_title' => 'General Knowledge Quiz',
        'exam_description' => 'A basic quiz on general knowledge',
        'exam_date' => '2023-12-31',
        'exam_duration' => 30,
        'total_questions' => 3
    ]
];

foreach ($exams as $exam) {
    $exam_title = $conn->real_escape_string($exam['exam_title']);
    $exam_description = $conn->real_escape_string($exam['exam_description']);
    $exam_date = $conn->real_escape_string($exam['exam_date']);
    $exam_duration = $exam['exam_duration'];
    $total_questions = $exam['total_questions'];

    $sql = "INSERT INTO tbl_exam (exam_title, exam_description, exam_date, exam_duration, total_questions) VALUES ('$exam_title', '$exam_description', '$exam_date', $exam_duration, $total_questions)";
    if ($conn->query($sql) === TRUE) {
        $exam_id = $conn->insert_id;
        echo "Exam inserted: $exam_title\n";
    } else {
        echo "Error inserting exam: " . $conn->error . "\n";
        $exam_id = 1; // fallback
    }
}

// Insert sample questions
$questions = [
    [
        'ques' => 'What is the capital of France?',
        'exam_id' => $exam_id,
        'answers' => [
            ['ans' => 'London', 'rightAns' => 0],
            ['ans' => 'Paris', 'rightAns' => 1],
            ['ans' => 'Berlin', 'rightAns' => 0],
            ['ans' => 'Madrid', 'rightAns' => 0]
        ]
    ],
    [
        'ques' => 'Which planet is known as the Red Planet?',
        'exam_id' => $exam_id,
        'answers' => [
            ['ans' => 'Venus', 'rightAns' => 0],
            ['ans' => 'Mars', 'rightAns' => 1],
            ['ans' => 'Jupiter', 'rightAns' => 0],
            ['ans' => 'Saturn', 'rightAns' => 0]
        ]
    ],
    [
        'ques' => 'What is 2 + 2?',
        'exam_id' => $exam_id,
        'answers' => [
            ['ans' => '3', 'rightAns' => 0],
            ['ans' => '4', 'rightAns' => 1],
            ['ans' => '5', 'rightAns' => 0],
            ['ans' => '6', 'rightAns' => 0]
        ]
    ]
];

foreach ($questions as $q) {
    $ques = $conn->real_escape_string($q['ques']);
    $exam_id_q = $q['exam_id'];

    $sql = "INSERT INTO tbl_ques (ques, exam_id) VALUES ('$ques', '$exam_id_q')";
    if ($conn->query($sql) === TRUE) {
        $quesNo = $conn->insert_id;
        echo "Question inserted: $ques\n";

        foreach ($q['answers'] as $ans) {
            $rightAns = $ans['rightAns'];
            $ansText = $conn->real_escape_string($ans['ans']);
            $sql = "INSERT INTO tbl_ans (quesNo, rightAns, ans) VALUES ($quesNo, $rightAns, '$ansText')";
            if ($conn->query($sql) === TRUE) {
                echo "Answer inserted: $ansText\n";
            } else {
                echo "Error inserting answer: " . $conn->error . "\n";
            }
        }
    } else {
        echo "Error inserting question: " . $conn->error . "\n";
    }
}

$conn->close();
echo "Setup completed.\n";
?>
