<?php

// Script to fix the tbl_ques table by adding exam_id column if missing

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "mcqexamination";

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if exam_id column exists in tbl_ques
$result = $conn->query("SHOW COLUMNS FROM tbl_ques LIKE 'exam_id'");
if ($result->num_rows == 0) {
    // Column doesn't exist, add it
    $sql = "ALTER TABLE tbl_ques ADD COLUMN exam_id INT(11) NOT NULL AFTER ques";
    if ($conn->query($sql) === TRUE) {
        echo "Column exam_id added successfully to tbl_ques\n";
    } else {
        echo "Error adding column: " . $conn->error . "\n";
    }

    // Add foreign key constraint
    $sql = "ALTER TABLE tbl_ques ADD CONSTRAINT fk_exam_id FOREIGN KEY (exam_id) REFERENCES tbl_exam(exam_id)";
    if ($conn->query($sql) === TRUE) {
        echo "Foreign key constraint added successfully\n";
    } else {
        echo "Error adding foreign key: " . $conn->error . "\n";
    }
} else {
    echo "Column exam_id already exists in tbl_ques\n";
}

// Check if tbl_exam exists, if not create it
$result = $conn->query("SHOW TABLES LIKE 'tbl_exam'");
if ($result->num_rows == 0) {
    // Create tbl_exam table
    $sql = "CREATE TABLE tbl_exam (
        exam_id INT(11) NOT NULL AUTO_INCREMENT,
        exam_title VARCHAR(255) NOT NULL,
        exam_description TEXT,
        exam_date DATE NOT NULL,
        exam_duration INT(11) NOT NULL COMMENT 'in minutes',
        total_questions INT(11) NOT NULL,
        status ENUM('Active','Inactive') DEFAULT 'Active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (exam_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

    if ($conn->query($sql) === TRUE) {
        echo "Table tbl_exam created successfully\n";

        // Insert a default exam
        $sql = "INSERT INTO tbl_exam (exam_title, exam_description, exam_date, exam_duration, total_questions) VALUES ('Default Exam', 'Default exam for questions', '2023-12-31', 30, 10)";
        if ($conn->query($sql) === TRUE) {
            echo "Default exam inserted\n";
        } else {
            echo "Error inserting default exam: " . $conn->error . "\n";
        }
    } else {
        echo "Error creating table tbl_exam: " . $conn->error . "\n";
    }
} else {
    echo "Table tbl_exam already exists\n";
}

$conn->close();
echo "Fix completed.\n";
?>
