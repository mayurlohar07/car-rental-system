<?php
include 'classes/Exam.php';
$exam = new Exam();

$data = array(
    'exam_id' => 1, // PHP Exam
    'ques' => 'What is PHP?',
    'ans1' => 'Hypertext Preprocessor',
    'ans2' => 'Personal Home Page',
    'ans3' => 'Pre Hypertext Processor',
    'ans4' => 'None',
    'rightAns' => 1
);
$result = $exam->getAddQuestion($data);
echo $result;
 