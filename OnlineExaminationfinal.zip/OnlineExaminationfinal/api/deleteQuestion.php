<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$questionsFile = '../react-online-exam/public/questions.json';

if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $quesNo = isset($_GET['quesNo']) ? (int)$_GET['quesNo'] : null;

    if (!$quesNo) {
        echo json_encode(['success' => false, 'message' => 'Question number is required']);
        exit;
    }

    if (file_exists($questionsFile)) {
        $questions = json_decode(file_get_contents($questionsFile), true);
        $questions = array_filter($questions, function($q) use ($quesNo) {
            return $q['quesNo'] != $quesNo;
        });

        if (file_put_contents($questionsFile, json_encode(array_values($questions), JSON_PRETTY_PRINT))) {
            echo json_encode(['success' => true, 'message' => 'Question deleted successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to delete question']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Questions file not found']);
    }
}
?>
