<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// DB CONNECTION
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "mcqexamination";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Read JSON sent from React
    $data = json_decode(file_get_contents('php://input'), true);

    if (!$data) {
        echo json_encode(['success' => false, 'message' => 'Invalid JSON input']);
        exit;
    }

    // Extract fields
    $examName = $conn->real_escape_string($data['examName']);
    $examDesc = $conn->real_escape_string($data['examDesc']);
    $examDate = $conn->real_escape_string($data['examDate']);
    $examDuration = intval($data['examDuration']);
    $totalQuestions = intval($data['totalQuestions']);

    // Insert into table
    $sql = "INSERT INTO tbl_exam (exam_name, exam_desc, exam_date, duration_minutes, total_questions)
            VALUES ('$examName', '$examDesc', '$examDate', $examDuration, $totalQuestions)";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Exam added successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }

} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {

    // Fetch all exams (optional)
    $result = $conn->query("SELECT * FROM tbl_exam ORDER BY id DESC");

    $exams = [];
    while ($row = $result->fetch_assoc()) {
        $exams[] = $row;
    }

    echo json_encode($exams);
}

$conn->close();
?>
