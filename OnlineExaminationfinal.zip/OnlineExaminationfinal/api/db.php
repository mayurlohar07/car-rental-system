<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "mcqexamination";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die(json_encode(["message" => "Database connection failed"]));
}
?>
