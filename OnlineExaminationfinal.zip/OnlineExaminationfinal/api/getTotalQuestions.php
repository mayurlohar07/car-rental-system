<?php
include '../inc/api_init.php';

$exam = new Exam();
$total = $exam->getTotalRows();

echo json_encode(['total' => $total]);
?>
