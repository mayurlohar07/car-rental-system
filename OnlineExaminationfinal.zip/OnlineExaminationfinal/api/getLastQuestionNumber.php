<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

$exam_id = $_GET["exam_id"];

$conn = new mysqli("localhost", "root", "", "mcqexamination");

$res = $conn->query("SELECT MAX(que_number) AS lastQ FROM tbl_questions WHERE exam_id = $exam_id");
$row = $res->fetch_assoc();

$nextQ = $row["lastQ"] ? $row["lastQ"] + 1 : 1;

echo json_encode(["nextQuesNo" => $nextQ]);
?>
