<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

include_once '../classes/User.php';

$user = new User();
$users = [];

// Get users from database
$userData = $user->getUserData();
if ($userData) {
    while ($result = $userData->fetch_assoc()) {
        $users[] = [
            'userId' => (int)$result['userId'],
            'name' => $result['name'],
            'userName' => $result['userName'],
            'email' => $result['email'],
            'status' => $result['status']
        ];
    }
}

// Get users from JSON file
$jsonFile = '../react-online-exam/public/users.json';
if (file_exists($jsonFile)) {
    $jsonUsers = json_decode(file_get_contents($jsonFile), true);
    if ($jsonUsers) {
        $users = array_merge($users, $jsonUsers);
    }
}

// Handle DELETE request
if ($_SERVER['REQUEST_METHOD'] === 'DELETE' && isset($_GET['del'])) {
    $delid = (int)$_GET['del'];

    // Try to delete from database first
    $deluser = $user->delUser($delid);

    // Also remove from JSON file if exists
    if (file_exists($jsonFile)) {
        $jsonUsers = json_decode(file_get_contents($jsonFile), true);
        $jsonUsers = array_filter($jsonUsers, function($u) use ($delid) {
            return $u['userId'] != $delid;
        });
        file_put_contents($jsonFile, json_encode(array_values($jsonUsers), JSON_PRETTY_PRINT));
    }

    echo json_encode(['success' => true, 'message' => 'User deleted']);
    exit;
}

echo json_encode($users);
?>
