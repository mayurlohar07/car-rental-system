<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

// DATABASE CONNECTION
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "mcqexamination";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit;
}

// Fetch all exams
$sql = "SELECT * FROM tbl_exam ORDER BY exam_id DESC";
$result = $conn->query($sql);

$exams = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $exams[] = $row;
    }
}

// Output JSON
echo json_encode($exams);

$conn->close();
?>
