<?php
include '../lib/Session.php';
include '../lib/Database.php';

Session::init();
$db = new Database();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// ==============================
// ❌ METHOD CHECK
// ==============================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// ==============================
// 📥 INPUT
// ==============================
$userName = $_POST['userName'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($userName) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Username and password are required']);
    exit;
}

// ==============================
// 📂 READ JSON USERS
// ==============================
$usersFile = '../react-online-exam/public/users.json';

if (!file_exists($usersFile)) {
    echo json_encode(['success' => false, 'message' => 'User database not found']);
    exit;
}

$users = json_decode(file_get_contents($usersFile), true);

if (!$users) {
    echo json_encode(['success' => false, 'message' => 'Invalid user database']);
    exit;
}

// ==============================
// 🔍 FIND USER
// ==============================
$userFound = null;

foreach ($users as $user) {
    if ($user['userName'] === $userName) {
        $userFound = $user;
        break;
    }
}

if (!$userFound) {
    echo json_encode(['success' => false, 'message' => 'Username not found']);
    exit;
}

// ==============================
// 🔐 PASSWORD CHECK
// ==============================
if ($userFound['password'] !== $password) {
    echo json_encode(['success' => false, 'message' => 'Incorrect password']);
    exit;
}

// ==============================
// 🚫 STATUS CHECK
// ==============================
if ($userFound['status'] !== '0') {
    echo json_encode(['success' => false, 'message' => 'Account is disabled']);
    exit;
}

// ==============================
// 🔥 AUTO INSERT USER IN DB (IMPORTANT FIX)
// ==============================
$userId   = $userFound['userId'];
$name     = $userFound['name'];
$userName = $userFound['userName'];
$email    = $userFound['email'];

// Check if user already exists in DB
$checkUser = $db->select("SELECT * FROM tbl_user WHERE userId = '$userId'");

if (!$checkUser) {
    $insertUser = "
        INSERT INTO tbl_user (userId, name, userName, email, status)
        VALUES ('$userId', '$name', '$userName', '$email', 0)
    ";
    $db->insert($insertUser);
}

// ==============================
// 🔥 SET SESSION
// ==============================
Session::set("login", true);
Session::set("userId", $userId);
Session::set("userName", $userName);

// ==============================
// ✅ RESPONSE
// ==============================
echo json_encode([
    'success' => true,
    'message' => 'Login successful',
    'user' => [
        'userId' => $userId,
        'name' => $name,
        'userName' => $userName,
        'email' => $email
    ]
]);
?>