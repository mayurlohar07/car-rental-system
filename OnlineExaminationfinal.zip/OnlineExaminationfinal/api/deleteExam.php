<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    exit(0); 
}

// Check exam_id exists
if (!isset($_GET['exam_id'])) {
    echo json_encode([
        "success" => false,
        "message" => "No exam_id provided"
    ]);
    exit;
}

$exam_id = (int) $_GET['exam_id'];

// DB CONNECTION
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "mcqexamination";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    echo json_encode([
        "success" => false,
        "message" => "Database connection failed"
    ]);
    exit;
}

// DELETE QUERY
$sql = "DELETE FROM tbl_exam WHERE exam_id = $exam_id";

if ($conn->query($sql)) {
    echo json_encode([
        "success" => true,
        "message" => "Exam deleted successfully"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Failed to delete exam"
    ]);
}

$conn->close();
?>
