<?php
include '../inc/api_init.php';

if (!isset($_GET['q'])) {
    echo json_encode(['error' => 'Question number not specified']);
    exit;
}

$quesnumber = (int) $_GET['q'];

$question = $exam->getQuestionNumber($quesnumber);
if (!$question) {
    echo json_encode(['error' => 'Question not found']);
    exit;
}

$answersResult = $exam->getAnswer($quesnumber);
$answers = [];
if ($answersResult) {
    while ($row = $answersResult->fetch_assoc()) {
        $answers[] = $row;
    }
}

echo json_encode([
    'question' => $question,
    'answers' => $answers
]);
?>
