<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

$user_id = $_GET["user_id"];
$exam_id = $_GET["exam_id"];

$conn = new mysqli("localhost", "root", "", "mcqexamination");

$sql = "SELECT * FROM tbl_score WHERE user_id = $user_id AND exam_id = $exam_id";
$result = $conn->query($sql);

echo json_encode(["attempted" => $result->num_rows > 0]);
?>
