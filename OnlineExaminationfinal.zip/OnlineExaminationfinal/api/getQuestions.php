<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "mcqexamination");

if ($conn->connect_error) {
    echo json_encode([]);
    exit;
}

$exam_id = $_GET["exam_id"];

$sql = "SELECT * FROM tbl_qands WHERE exam_id = $exam_id ORDER BY ques_number ASC";
$result = $conn->query($sql);

$questions = [];

while ($row = $result->fetch_assoc()) {
    $questions[] = $row;
}

echo json_encode($questions);
?>
