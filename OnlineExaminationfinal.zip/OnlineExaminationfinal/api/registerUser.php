<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Read POST form data
$name = $_POST['name'] ?? '';
$userName = $_POST['userName'] ?? '';
$email = $_POST['email'] ?? '';
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);


if (empty($name) || empty($userName) || empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit;
}

// Database connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "mcqexamination";

$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

// Check if username exists
$checkUser = $conn->prepare("SELECT userId FROM tbl_user WHERE userName = ?");
$checkUser->bind_param("s", $userName);
$checkUser->execute();
$checkUser->store_result();

if ($checkUser->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Username already exists']);
    exit;
}

// Check if email exists
$checkEmail = $conn->prepare("SELECT userId FROM tbl_user WHERE email = ?");
$checkEmail->bind_param("s", $email);
$checkEmail->execute();
$checkEmail->store_result();

if ($checkEmail->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Email already exists']);
    exit;
}

// Insert new user
$status = 0;
$insert = $conn->prepare("
    INSERT INTO tbl_user (name, userName, password, email, status)
    VALUES (?, ?, ?, ?, ?)
");
$insert->bind_param("ssssi", $name, $userName, $password, $email, $status);

if ($insert->execute()) {
    echo json_encode(['success' => true, 'message' => 'Registration successful!']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to save user data']);
}

$conn->close();
?>
