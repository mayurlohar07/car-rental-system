<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    exit(0);
}

$data = json_decode(file_get_contents("php://input"), true);

$user_id = intval($data["user_id"]);
$exam_id = intval($data["exam_id"]);
$score   = intval($data["score"]);


$conn = new mysqli("localhost", "root", "", "mcqexamination");

$stmt = $conn->prepare("INSERT INTO tbl_score (user_id, exam_id, score) VALUES (?, ?, ?)");
$stmt->bind_param("iii", $user_id, $exam_id, $score);

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "error" => $stmt->error]);
}

$stmt->close();
$conn->close();
?>
