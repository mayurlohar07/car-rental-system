<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    exit(0);
}

$conn = new mysqli("localhost", "root", "", "mcqexamination");

if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "DELETE") {
    $que_id = isset($_GET["que_id"]) ? intval($_GET["que_id"]) : 0;

    if ($que_id <= 0) {
        echo json_encode(["success" => false, "message" => "Invalid que_id"]);
        exit;
    }

    $sql = "DELETE FROM tbl_qands WHERE que_id = $que_id";

    if ($conn->query($sql)) {
        echo json_encode(["success" => true, "message" => "Question deleted successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to delete question"]);
    }
}

$conn->close();
?>
