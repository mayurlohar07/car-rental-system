<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, OPTIONS");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    exit(0);
}

$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    echo json_encode(["success" => false, "message" => "Invalid JSON input"]);
    exit;
}

$exam_id = $data["exam_id"];
$que_number = $data["que_number"];   // React sends this
$question = $data["question"];
$answer = $data["answer"];
$option1 = $data["option1"];
$option2 = $data["option2"];
$option3 = $data["option3"];
$option4 = $data["option4"];

// DB Connection
$conn = new mysqli("localhost", "root", "", "mcqexamination");

if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "DB Connection Failed"]);
    exit;
}

// IMPORTANT: use correct column name: ques_number
$sql = "INSERT INTO tbl_qands 
        (exam_id, ques_number, question, answer, option1, option2, option3, option4)
        VALUES 
        ('$exam_id', '$que_number', '$question', '$answer', '$option1', '$option2', '$option3', '$option4')";

if ($conn->query($sql)) {
    echo json_encode(["success" => true, "message" => "Question Added Successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "DB Error: " . $conn->error]);
}

$conn->close();
?>
