<?php 
include 'inc/header.php'; 

Session::checkSession();

$exam_id   = Session::get("exam_id");
$user_id   = Session::get("userId");
$username  = Session::get("userName");

// ====================== CALCULATE SCORE ======================
$saved_answers = $_SESSION['saved_answers'] ?? [];
$score = 0;

if (isset($_SESSION['score']) && $_SESSION['score'] > 0) {
    $score = $_SESSION['score'];
} else {
    foreach ($saved_answers as $qnum => $selected_ans) {
        $q = $exam->getQuestionNumber($exam_id, $qnum);

        // Safe Check for correct_ans
        if ($q && isset($q['correct_ans']) && $q['correct_ans'] == $selected_ans) {
            $score++;
        }
    }
}

// ====================== TOTAL QUESTIONS ======================
$query = "SELECT COUNT(*) AS total FROM tbl_qands WHERE exam_id = '$exam_id'";
$totalResult = $db->select($query);
$total_questions = ($totalResult && $totalResult->num_rows > 0) 
                    ? $totalResult->fetch_assoc()['total'] 
                    : 0;

// ====================== EXAM NAME ======================
$query2 = "SELECT exam_name FROM tbl_exam WHERE exam_id = '$exam_id'";
$examData = $db->select($query2);
$exam_name = ($examData && $examData->num_rows > 0) 
              ? $examData->fetch_assoc()['exam_name'] 
              : 'Unknown Exam';

// ====================== STATS ======================
$percentage        = ($total_questions > 0) ? round(($score / $total_questions) * 100) : 0;
$correct_questions = $score;
$wrong_questions   = $total_questions - $score;
$unanswered        = $total_questions - count($saved_answers);
$attempt_date      = date("Y-m-d H:i:s");

// ====================== SAVE RESULT ======================
$checkQuery = "SELECT * FROM tbl_results 
               WHERE user_id = '$user_id' AND exam_id = '$exam_id' 
               ORDER BY id DESC LIMIT 1";

$checkResult = $db->select($checkQuery);

if (!$checkResult || $checkResult->num_rows == 0) {

    $insertQuery = "INSERT INTO tbl_results 
        (user_id, username, exam_id, attempt_date, percentage, total_questions, correct_questions, wrong_questions)
        VALUES 
        ('$user_id', '$username', '$exam_id', '$attempt_date', '$percentage', '$total_questions', '$correct_questions', '$wrong_questions')";

    $db->insert($insertQuery);
}

// ====================== CLEAR SESSION ======================
unset($_SESSION['score']);
unset($_SESSION['saved_answers']);
unset($_SESSION['exam_start_time']);
?>

<style>
body { background:#f4f6f9; }
.result-box {
    background:#ffffff;
    padding:45px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    margin-top:50px;
    margin-bottom:50px;
}
.success-title { font-size:38px; font-weight:700; }
.score-box {
    background:linear-gradient(135deg,#007bff,#6610f2);
    color:#fff;
    padding:35px;
    border-radius:15px;
    margin:25px 0;
}
.score-main { font-size:52px; font-weight:700; }
.stats p { font-size:20px; margin-bottom:10px; }
.btn-custom {
    padding:12px 28px;
    font-size:18px;
    border-radius:10px;
    margin:5px;
}
</style>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-8 text-center">

            <div class="result-box">

                <?php if (isset($_GET['timeout'])) { ?>
                    <h1 class="text-warning success-title">⏱ Time's Up!</h1>
                    <p class="lead">Your exam has been auto-submitted.</p>
                <?php } else { ?>
                    <h1 class="text-success success-title">🎉 Congratulations!</h1>
                    <p class="lead">
                        You have successfully completed <strong><?php echo $exam_name; ?></strong>
                    </p>
                <?php } ?>

                <div class="score-box">
                    <h3>Your Score</h3>
                    <div class="score-main">
                        <?php echo $score . " / " . $total_questions; ?>
                    </div>
                    <h4>Percentage: <?php echo $percentage; ?>%</h4>
                </div>

                <div class="stats">
                    <p class="text-success">
                        ✔ Correct Answers: <strong><?php echo $correct_questions; ?></strong>
                    </p>
                    <p class="text-danger">
                        ✘ Wrong Answers: <strong><?php echo $wrong_questions; ?></strong>
                    </p>
                    <?php if ($unanswered > 0) { ?>
                    <p class="text-secondary">
                        — Unanswered: <strong><?php echo $unanswered; ?></strong>
                    </p>
                    <?php } ?>
                </div>

                <br>
                <a class="btn btn-outline-success btn-lg btn-custom" href="viewans.php">
                    <span class="fa fa-check-circle"></span> View Correct Answers
                </a>
                <a class="btn btn-outline-info btn-lg btn-custom" href="starttest.php">
                    <span class="fa fa-arrow-right"></span> Start Again
                </a>

            </div>
        </div>
    </div>
</div>

<?php include 'inc/footer.php'; ?>