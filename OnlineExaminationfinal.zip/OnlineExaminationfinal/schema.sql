CREATE DATABASE IF NOT EXISTS mcqexamination;
USE mcqexamination;

-- ==========================
-- tbl_admin
-- ==========================
CREATE TABLE tbl_admin (
    adminId INT NOT NULL AUTO_INCREMENT,
    adminUser VARCHAR(100) NOT NULL,
    adminPass VARCHAR(255) NOT NULL,
    PRIMARY KEY (adminId)
);

-- ==========================
-- tbl_user
-- ==========================
CREATE TABLE tbl_user (
    userId INT NOT NULL AUTO_INCREMENT,
    Name VARCHAR(100) NOT NULL,
    userName VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(150) NOT NULL,
    status TINYINT(1) DEFAULT 0,
    PRIMARY KEY (userId)
);

-- ==========================
-- tbl_exam
-- ==========================
CREATE TABLE tbl_exam (
    exam_id INT NOT NULL AUTO_INCREMENT,
    exam_name VARCHAR(200) NOT NULL,
    exam_desc TEXT,
    exam_date DATE,
    exam_time TIME NULL,
    duration_minutes INT,
    total_questions INT,
    total_marks INT,
    status VARCHAR(20) DEFAULT 'inactive',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (exam_id)
);

-- ==========================
-- tbl_qands
-- ==========================
CREATE TABLE tbl_qands (
    que_id INT NOT NULL AUTO_INCREMENT,
    exam_id INT NOT NULL,
    ques_number INT NOT NULL,
    question TEXT NOT NULL,
    answer VARCHAR(255) NOT NULL,
    option1 VARCHAR(255) NOT NULL,
    option2 VARCHAR(255) NOT NULL,
    option3 VARCHAR(255) NOT NULL,
    option4 VARCHAR(255) NOT NULL,
    PRIMARY KEY (que_id),
    FOREIGN KEY (exam_id) REFERENCES tbl_exam(exam_id)
);

-- ==========================
-- tbl_score
-- ==========================
CREATE TABLE tbl_score (
    score_id INT NOT NULL AUTO_INCREMENT,
    user_id INT NOT NULL,
    exam_id INT NOT NULL,
    username VARCHAR(100) NOT NULL,
    score INT NOT NULL,
    PRIMARY KEY (score_id),
    FOREIGN KEY (user_id) REFERENCES tbl_user(userId),
    FOREIGN KEY (exam_id) REFERENCES tbl_exam(exam_id)
);
