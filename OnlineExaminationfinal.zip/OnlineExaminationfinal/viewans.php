<?php include 'inc/header.php'; ?>
<?php
Session::checkSession();

$exam_id = Session::get("exam_id");

$total = $exam->getTotalRows($exam_id);
$getQues = $exam->getQuestionsByExam($exam_id);

$userAnswers = isset($_SESSION['user_answers']) ? $_SESSION['user_answers'] : [];
?>

<div class="container py-4">

    <!-- HEADER CARD -->
    <div class="card shadow-sm mb-4 border-0">
        <div class="card-body text-center">
            <h2 class="fw-bold text-primary">
                All Questions & Answers
            </h2>
            <p class="text-muted mb-0">
                Total Questions: <strong><?php echo $total; ?></strong>
            </p>
        </div>
    </div>

    <!-- QUESTIONS LOOP -->
    <?php 
    if ($getQues) {
        while ($q = $getQues->fetch_assoc()) {

            $qn      = $q['ques_number'];
            $correct = $q['answer'];
            $userSel = $userAnswers[$qn] ?? 0;
    ?>

    <div class="card mb-4 shadow-sm border-0">
        <div class="card-body">

            <!-- QUESTION -->
            <h5 class="fw-bold mb-3 text-dark">
                Q<?php echo $qn; ?>. <?php echo $q['question']; ?>
            </h5>

            <!-- OPTIONS -->
            <div class="list-group">

                <!-- OPTION 1 -->
                <div class="list-group-item">
                    <?php
                        if ($correct == 1) {
                            echo "<span class='text-success fw-bold'>{$q['option1']} (Correct)</span>";
                        } 
                        else if ($userSel == 1) {
                            echo "<span class='text-danger fw-bold'>{$q['option1']} (Your Answer)</span>";
                        } else {
                            echo $q['option1'];
                        }
                    ?>
                </div>

                <!-- OPTION 2 -->
                <div class="list-group-item">
                    <?php
                        if ($correct == 2) {
                            echo "<span class='text-success fw-bold'>{$q['option2']} (Correct)</span>";
                        } 
                        else if ($userSel == 2) {
                            echo "<span class='text-danger fw-bold'>{$q['option2']} (Your Answer)</span>";
                        } else {
                            echo $q['option2'];
                        }
                    ?>
                </div>

                <!-- OPTION 3 -->
                <div class="list-group-item">
                    <?php
                        if ($correct == 3) {
                            echo "<span class='text-success fw-bold'>{$q['option3']} (Correct)</span>";
                        } 
                        else if ($userSel == 3) {
                            echo "<span class='text-danger fw-bold'>{$q['option3']} (Your Answer)</span>";
                        } else {
                            echo $q['option3'];
                        }
                    ?>
                </div>

                <!-- OPTION 4 -->
                <div class="list-group-item">
                    <?php
                        if ($correct == 4) {
                            echo "<span class='text-success fw-bold'>{$q['option4']} (Correct)</span>";
                        } 
                        else if ($userSel == 4) {
                            echo "<span class='text-danger fw-bold'>{$q['option4']} (Your Answer)</span>";
                        } else {
                            echo $q['option4'];
                        }
                    ?>
                </div>

            </div>
        </div>
    </div>

    <?php } } ?>

    <!-- BUTTON -->
    <div class="text-center mt-4">
        <a href="starttest.php" class="btn btn-success btn-lg px-5">
            Start Exam Again
        </a>
    </div>

</div>

<?php include 'inc/footer.php'; ?>