<?php include 'inc/header.php'; ?>

<div class="container py-5">

    <div class="row justify-content-center">

        <div class="col-lg-8">

            <div class="card border-0 shadow-lg rounded-4 overflow-hidden">

                <!-- Top Header -->
                <div class="text-center p-5 text-white" style="background:linear-gradient(135deg,#0d6efd,#6f42c1);">

                    <h1 class="fw-bold mb-2">Online Examination System</h1>

                    <p class="lead mb-3">Complete MCQ Based Online Examination System!</p>

                    <img src="img/regi.png" width="110">

                </div>

                <!-- Form Section -->
                <div class="p-5 bg-white">

                    <div class="form-group mb-4">
                        <label class="fw-bold mb-2">Full Name</label>
                        <input type="text" class="form-control form-control-lg rounded-3" id="name" name="name" placeholder="Enter Your Full Name">
                        <small class="form-text text-muted">Enter your full name (spaces allowed).</small>
                    </div>

                    <div class="form-group mb-4">
                        <label class="fw-bold mb-2">Username</label>
                        <input type="text" class="form-control form-control-lg rounded-3" id="userName" name="userName" placeholder="Enter Username (without spaces)">
                        <small class="form-text text-muted">Enter only the username.</small>
                    </div>

                    <div class="form-group mb-4">
                        <label class="fw-bold mb-2">Email Address</label>
                        <input type="email" class="form-control form-control-lg rounded-3" id="email" name="email" placeholder="Enter Email">
                        <small class="form-text text-muted">We'll never share your email with anyone else.</small>
                    </div>

                    <div class="form-group mb-4">
                        <label class="fw-bold mb-2">Password</label>
                        <input type="password" name="password" id="password" class="form-control form-control-lg rounded-3" placeholder="Password">
                    </div>

                    <!-- Buttons -->
                    <div class="d-grid gap-3">
                        <button type="submit" id="registersubm" value="Signup" class="btn btn-success btn-lg rounded-3 shadow-sm">
                            Register Now
                        </button>

                        <a class="btn btn-outline-danger btn-lg rounded-3" href="index.php">
                            Already Registered? Login
                        </a>
                    </div>

                    <br>

                    <span id="state"></span>

                </div>

            </div>

        </div>

    </div>

</div>

<?php include 'inc/footer.php'; ?>