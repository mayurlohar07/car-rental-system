<?php 

$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/../lib/Session.php');
include_once ($filepath.'/../lib/Database.php');
include_once ($filepath.'/../helpers/Format.php');

class Process {
    private $db;
    private $fm;

    public function __construct() {
        $this->db = new Database();
        $this->fm = new Format();
    }

    // MAIN FUNCTION
    public function getProcessData($data) {

        $selectedAns = $this->fm->validation($data['ans']);     // 1-4
        $ques_number = $this->fm->validation($data['quesnumber']);
        $exam_id     = $this->fm->validation($data['exam_id']);

        $selectedAns = mysqli_real_escape_string($this->db->link, $selectedAns);
        $ques_number = mysqli_real_escape_string($this->db->link, $ques_number);
        $exam_id     = mysqli_real_escape_string($this->db->link, $exam_id);

        $next = $ques_number + 1;

        // Initialize score
        if (!isset($_SESSION['score'])) {
            $_SESSION['score'] = 0;
        }

        // GET TOTAL QUESTIONS
        $total = $this->getTotalQuestions($exam_id);

        // CHECK CORRECT ANSWER
        $correct = $this->getCorrectAnswer($exam_id, $ques_number);

        if ($selectedAns == $correct) {
            $_SESSION['score']++;
        }

        // LAST QUESTION?
        if ($ques_number == $total) {

            // ----------------------------------------
            // SAVE SCORE TO DATABASE
            // ----------------------------------------
            $this->saveScore($exam_id, $_SESSION['score']);

            header("Location: final.php");
            exit();
        } 
        else {
            header("Location: test.php?q=" . $next . "&exam_id=" . $exam_id);
            exit();
        }
    }

    // SAVE SCORE TO tbl_score
    private function saveScore($exam_id, $score) {
        $user_id  = Session::get("userId");
        $username = Session::get("userName");

        // Prevent duplicate score entry
        $checkQuery = "
            SELECT * FROM tbl_score 
            WHERE user_id = '$user_id' AND exam_id = '$exam_id'
        ";

        $check = $this->db->select($checkQuery);

        if ($check && $check->num_rows > 0) {
            // Update score if already exists
            $updateQuery = "
                UPDATE tbl_score 
                SET score = '$score' 
                WHERE user_id = '$user_id' AND exam_id = '$exam_id'
            ";
            $this->db->update($updateQuery);
        } 
        else {
            // Insert new row
            $insertQuery = "
                INSERT INTO tbl_score(user_id, exam_id, username, score)
                VALUES('$user_id', '$exam_id', '$username', '$score')
            ";
            $this->db->insert($insertQuery);
        }
    }

    // GET TOTAL QUESTIONS
    private function getTotalQuestions($exam_id) {
        $query = "SELECT * FROM tbl_qands WHERE exam_id = '$exam_id'";
        $result = $this->db->select($query);
        return ($result) ? $result->num_rows : 0;
    }

    // GET CORRECT ANSWER
    private function getCorrectAnswer($exam_id, $ques_number) {
        $query = "
            SELECT answer 
            FROM tbl_qands 
            WHERE exam_id = '$exam_id' AND ques_number = '$ques_number'
        ";

        $result = $this->db->select($query)->fetch_assoc();
        return $result['answer']; // returns number (1,2,3,4)
    }
}

?>
