<?php 

$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/../lib/Database.php');
include_once ($filepath.'/../helpers/Format.php');

class Exam {
    private $db;
    private $fm;

    public function __construct() {
        $this->db = new Database();
        $this->fm = new Format();
    }

    // --------------------------------------------------------
    // ADD QUESTION (SAFE)
    // --------------------------------------------------------
    public function addQuestionToExam($data) {

        $exam_id  = (int)$data['exam_id'];
        $question = trim($data['question']);
        $option1  = trim($data['option1']);
        $option2  = trim($data['option2']);
        $option3  = trim($data['option3']);
        $option4  = trim($data['option4']);
        $answer   = (int)$data['answer'];

        // VALIDATION
        if (!$exam_id || !$question || !$option1 || !$option2 || !$option3 || !$option4 || !$answer) {
            return "<div class='alert alert-danger'>All fields are required!</div>";
        }

        // GET NEXT QUESTION NUMBER (SAFE)
        $stmt = $this->db->link->prepare("SELECT IFNULL(MAX(ques_number),0)+1 AS next_q FROM tbl_qands WHERE exam_id=?");
        $stmt->bind_param("i", $exam_id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $ques_number = $result['next_q'];

        // INSERT
        $stmt = $this->db->link->prepare("
            INSERT INTO tbl_qands
            (exam_id, ques_number, question, option1, option2, option3, option4, answer)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->bind_param("iissssss", $exam_id, $ques_number, $question, $option1, $option2, $option3, $option4, $answer);

        return $stmt->execute()
            ? "<div class='alert alert-success'>Question Added Successfully!</div>"
            : "<div class='alert alert-danger'>Failed to Add Question.</div>";
    }

    // --------------------------------------------------------
    // UPDATE QUESTION (🔥 NEW FIXED)
    // --------------------------------------------------------
    public function updateQuestion($que_id, $question, $option1, $option2, $option3, $option4, $answer){

        $que_id = (int)$que_id;
        $question = trim($question);
        $option1  = trim($option1);
        $option2  = trim($option2);
        $option3  = trim($option3);
        $option4  = trim($option4);
        $answer   = (int)$answer;

        if (!$question || !$option1 || !$option2 || !$option3 || !$option4 || !$answer) {
            return "<div class='alert alert-danger'>All fields are required!</div>";
        }

        $stmt = $this->db->link->prepare("
            UPDATE tbl_qands
            SET question=?, option1=?, option2=?, option3=?, option4=?, answer=?
            WHERE que_id=?
        ");

        $stmt->bind_param("ssssssi", $question, $option1, $option2, $option3, $option4, $answer, $que_id);

        return $stmt->execute()
            ? "<div class='alert alert-success'>Question Updated Successfully!</div>"
            : "<div class='alert alert-danger'>Update Failed!</div>";
    }

    // --------------------------------------------------------
    // GET QUESTIONS
    // --------------------------------------------------------
    public function getQuestionsByExam($exam_id) {
        $stmt = $this->db->link->prepare("SELECT * FROM tbl_qands WHERE exam_id=? ORDER BY ques_number ASC");
        $stmt->bind_param("i", $exam_id);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function getQuestionNumber($exam_id, $ques_number) {
        $stmt = $this->db->link->prepare("SELECT * FROM tbl_qands WHERE exam_id=? AND ques_number=?");
        $stmt->bind_param("ii", $exam_id, $ques_number);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function getAnswerOptions($que_id) {
        $stmt = $this->db->link->prepare("SELECT * FROM tbl_qands WHERE que_id=?");
        $stmt->bind_param("i", $que_id);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function deleteQuestion($que_id) {
        $stmt = $this->db->link->prepare("DELETE FROM tbl_qands WHERE que_id=?");
        $stmt->bind_param("i", $que_id);

        return $stmt->execute()
            ? "<div class='alert alert-success'>Question Deleted Successfully!</div>"
            : "<div class='alert alert-danger'>Question Not Deleted.</div>";
    }

    public function getTotalRows($exam_id) {
        $stmt = $this->db->link->prepare("SELECT COUNT(*) as total FROM tbl_qands WHERE exam_id=?");
        $stmt->bind_param("i", $exam_id);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        return $res['total'];
    }

    // --------------------------------------------------------
    // ADD EXAM
    // --------------------------------------------------------
    public function getAddExam($data) {

        $name = trim($data['examName']);
        $desc = trim($data['examDesc']);
        $date = $data['examDate'];
        $duration = (int)$data['examDuration'];
        $total = (int)$data['totalQuestions'];
        $fee = (float)$data['exam_fee'];

        if (!$name || !$date || !$duration || !$total) {
            return "<div class='alert alert-danger'>Required fields missing!</div>";
        }

        $stmt = $this->db->link->prepare("
            INSERT INTO tbl_exam
            (exam_name, exam_desc, exam_date, duration_minutes, total_questions, exam_fee)
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        $stmt->bind_param("sssiii", $name, $desc, $date, $duration, $total, $fee);

        return $stmt->execute()
            ? "<div class='alert alert-success'>Exam Added Successfully!</div>"
            : "<div class='alert alert-danger'>Exam Not Added.</div>";
    }

    // --------------------------------------------------------
    // UPDATE EXAM
    // --------------------------------------------------------
    public function updateExam($data, $id){

        $id = (int)$id;
        $name = trim($data['examName']);
        $desc = trim($data['examDesc']);
        $date = $data['examDate'];
        $duration = (int)$data['examDuration'];
        $total = (int)$data['totalQuestions'];
        $fee = (float)$data['exam_fee'];

        $stmt = $this->db->link->prepare("
            UPDATE tbl_exam
            SET exam_name=?, exam_desc=?, exam_date=?, duration_minutes=?, total_questions=?, exam_fee=?
            WHERE exam_id=?
        ");

        $stmt->bind_param("sssiiii", $name, $desc, $date, $duration, $total, $fee, $id);

        return $stmt->execute()
            ? "<div class='alert alert-success'>Exam Updated Successfully</div>"
            : "<div class='alert alert-danger'>Update Failed</div>";
    }

    // --------------------------------------------------------
    // DELETE EXAM (TRANSACTION SAFE)
    // --------------------------------------------------------
    public function getDelExam($exam_id) {

        $exam_id = (int)$exam_id;

        $this->db->link->begin_transaction();

        try {
            $stmt1 = $this->db->link->prepare("DELETE FROM tbl_exam WHERE exam_id=?");
            $stmt1->bind_param("i", $exam_id);
            $stmt1->execute();

            $stmt2 = $this->db->link->prepare("DELETE FROM tbl_qands WHERE exam_id=?");
            $stmt2->bind_param("i", $exam_id);
            $stmt2->execute();

            $this->db->link->commit();

            return "<div class='alert alert-success'>Exam Deleted Successfully!</div>";

        } catch (Exception $e) {
            $this->db->link->rollback();
            return "<div class='alert alert-danger'>Failed to Delete Exam.</div>";
        }
    }

    // --------------------------------------------------------
    // GET ALL EXAMS
    // --------------------------------------------------------
    public function getAllExams() {
        return $this->db->select("SELECT * FROM tbl_exam ORDER BY exam_id DESC");
    }

    public function getExamById($id){
        $stmt = $this->db->link->prepare("SELECT * FROM tbl_exam WHERE exam_id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result();
    }
}
?>